"""Inventory this repository only; export existing LASR/live/functional evidence without inference."""
from pathlib import Path
import argparse,os,json,zipfile,hashlib,re
SKIP={'.git','.venv','venv','node_modules','__pycache__','dist','cache','REVISION_EVIDENCE_EXPORT','MISSING_VALIDATION_EVIDENCE'}
TEXT={'.json','.jsonl','.csv','.tsv','.txt','.md','.yaml','.yml'}
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=Path.cwd());a=ap.parse_args();root=a.root.resolve();out=root/'MISSING_VALIDATION_EVIDENCE';out.mkdir(exist_ok=True);inventory=[];exports=[];omitted=[];total=0
 for folder,dirs,files in os.walk(root,followlinks=False):
  dirs[:]=sorted(x for x in dirs if x not in SKIP and not (Path(folder)/x).is_symlink())
  for name in sorted(files):
   p=Path(folder)/name;rel=p.relative_to(root).as_posix();low=rel.lower()
   if p.is_symlink() or any(s in name.lower() for s in ['credential','secret','api_key','apikey','.env','auth.json']):continue
   wanted=any(s in low for s in ['lasr','ablation','weight_sensitivity','weight-sensitivity','live_validation','functional','reference_output','ndvi','worldcover','statistical_summary','matrix_results.jsonl'])
   if not wanted:continue
   try:size=p.stat().st_size
   except OSError:continue
   row={'path':rel,'size_bytes':size,'suffix':p.suffix};inventory.append(row)
   # Analytical rasters are inventoried, never automatically bundled here.
   if p.suffix.lower() not in TEXT:continue
   if size>30*1024**2 or total+size>150*1024**2:omitted.append({'path':rel,'reason':'size_limit'});continue
   try:raw=p.read_bytes()
   except OSError:omitted.append({'path':rel,'reason':'unreadable'});continue
   if re.search(rb'(?:sk-or-v1-|sk-proj-|AIza)[A-Za-z0-9_-]{20,}|-----BEGIN (?:RSA |EC )?PRIVATE KEY-----',raw):omitted.append({'path':rel,'reason':'possible_credential_skip_not_modified'});continue
   exports.append((p,rel,hashlib.sha256(raw).hexdigest().upper()));total+=size
 manifest={'artifact_id':'MMGIS_MISSING_VALIDATION_EXISTING_FILE_DISCOVERY','mode':'READ_ONLY_NO_API_NO_NEW_MODEL_CALLS','repository_name':root.name,'inventory':inventory,'exported':[{'path':r,'sha256':s} for p,r,s in exports],'omitted':omitted,'note':'No match is evidence only about this root. Existing results may be in another checkout. Do not regenerate model results merely to fill missing files.'}
 (out/'INVENTORY.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 with zipfile.ZipFile(out/'MISSING_VALIDATION_EVIDENCE.zip','w',zipfile.ZIP_DEFLATED) as z:
  for p,r,s in exports:z.write(p,r)
  z.writestr('DISCOVERY_INVENTORY.json',json.dumps(manifest,indent=2))
 print('MATCHED_FILES',len(inventory));print('EXPORTED_TEXT_FILES',len(exports));print('NEW_MODEL_CALLS',0);print('OUTPUT',out/'MISSING_VALIDATION_EVIDENCE.zip')
if __name__=='__main__':main()
