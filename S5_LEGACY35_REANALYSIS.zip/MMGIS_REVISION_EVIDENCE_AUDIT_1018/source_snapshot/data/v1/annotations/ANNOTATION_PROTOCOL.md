# MMGIS-Bench v1.0 Phase A — Independent GIS Annotation Protocol

## Status
This protocol is prespecified. The supplied task ground truth, LASR labels, functional tolerances, and non-text multimodal assets are **not frozen** and must not be represented as expert-validated until the steps below are completed.

## Roles and blinding
1. Expert A and Expert B work independently. Neither sees the other's file before both files are locked.
2. Annotators must not inspect model outputs for prospective tasks before completing and locking annotations.
3. Author proposals in `PROPOSED_GROUND_TRUTH_FOR_EXPERT_REVIEW.csv` are aids only. For the strongest independence, experts should annotate from task text first; proposals are consulted only during adjudication.
4. Record uncertainty rather than forcing agreement.

## Per-task annotation
For each prospective task record: (a) required operations; (b) partial-order constraints as ordered pairs; (c) acceptable functional alternatives; (d) suitable dataset requirements/identifiers where justified; (e) explicitly invalid operations; (f) confidence 1–5. Use `|` between operation names and JSON pairs for partial order.

## LASR candidate-layer annotation
Each task–layer pair is labelled `compatible`, `conditionally_compatible`, or `incompatible`. Inspect current authoritative metadata for temporal coverage, spatial coverage, native resolution/scale, provenance/access, and whether the layer supports the requested operation. Record the reason for conditional compatibility. Do not infer compatibility from semantic similarity alone.

## Multimodal asset review
For each M001–M040 intent, verify that text, speech, map image, and spatial graphic encode the same AOI, time, target variable and intended analysis. Speech must be human-checked against the intended transcript. Map/sketch assets must have known ground-truth geometry. Copyright/license/provenance must be recorded. Do not mark `frozen=true` until all four assets pass review.

## Functional validation
Before any candidate model execution, create the reference artifact and approve numerical/geometry tolerances. Tolerances must reflect expected numerical/resampling differences, not observed candidate errors. Any later tolerance change requires a documented protocol deviation and re-analysis.

## Lock and agreement
When an expert finishes, set `locked=true`, save a read-only copy, and compute SHA-256. Only after both are locked compute Cohen's kappa for categorical labels, operation-set Jaccard/F1, and pairwise order agreement. Then adjudicate disagreements in a separate file; never overwrite the two original annotations.

## Freeze gate
After adjudication and asset review: update approved prospective task fields, create final task JSON records under the v1 schema, set `frozen_before_model_run=true`; mark all 160 multimodal records `frozen=true`; compute SHA-256 manifests; commit/tag the repository. Only then should `scripts/v1/preflight_v1.py` return READY and final model runs begin.
