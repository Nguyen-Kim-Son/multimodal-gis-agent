# Legacy35 reanalysis

Recomputed from archived evaluator scores. Three generations averaged per task; 35 tasks are the statistical units. 10,000 task-bootstrap samples, seed 20261018. These intervals replace neither historical files nor raw responses.

| Model | Mean | 95% task-bootstrap interval |
|---|---:|---|
| gemma4_26b_free | 0.5625 | [0.4966, 0.6242] |
| qwen3_coder | 0.5567 | [0.4976, 0.6097] |
| gpt5_mini | 0.5234 | [0.4718, 0.5713] |
| gemini25_flash | 0.5080 | [0.4423, 0.5681] |
| gpt_oss20b_free | 0.4931 | [0.4288, 0.5520] |

## Composite score footnote draft
For these archived records, overall score is the arithmetic mean of the four reported scoring components: operation precision, operation recall, operation F1 and workflow order. Hallucinated-operation rate is reported separately and excluded from the mean, as are latency, token usage and cost. The formula was checked against all 525 records. Because precision, recall and F1 overlap, this mean is a descriptive evaluation convention, not four independent dimensions or an execution-accuracy measure.

## Evidence gaps
Both prospective annotation files have 65 rows but zero completed operation labels and zero locked rows. The 150 compatibility pairs have zero expert labels. All 30 functional-tolerance rows are PENDING. The live-validation table has no data rows. Do not compute human agreement or validation accuracy from these blank templates.

The 150-instance set has 450 records across three models with one record per instance/model; report descriptive values separately and do not treat template variants as 150 independent intents.

No LASR ablation/sensitivity raw runs were found in this export. Prior manuscript summaries are not independently reproduced by the present analysis.