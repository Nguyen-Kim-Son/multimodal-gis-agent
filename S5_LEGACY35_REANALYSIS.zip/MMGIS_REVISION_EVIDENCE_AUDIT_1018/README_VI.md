# Kiểm tra bằng chứng revision — 18/10/2026
663/663 file trong manifest đã khớp hash; 1 file SECRET_SCAN.json bị loại theo tên như thiết kế. Không có model call mới.

Đã tính lại legacy35: 525 records, 5 model ×35 task ×3 repeat. Đối chiếu lại overall score từ các thành phần và task aggregates đạt; dùng trung bình 3 repeat trong mỗi task/model rồi bootstrap 35 task, không coi 525 responses là 525 tasks. Có bảng mean/95% CI, 10 so sánh Wilcoxon ghép cặp/Holm, effect sizes, hình không dùng sao. Số liệu đầu vào ở source_snapshot; chạy REPRODUCE_ANALYSIS.py để tái tính ra recomputed. Cần numpy/pandas/scipy/matplotlib, không cần API key.

Điểm tổng hợp legacy là mean của precision, recall, F1, workflow order cho các records này; hallucination rate, latency, tokens, cost không tham gia mean. Không áp dụng công thức này vào M025. Đây là tái phân tích điểm đã lưu, không phải kiểm tra lại câu trả lời hay execution.

Chưa có raw LASR/sensitivity trong ZIP; nhãn chuyên gia prospective65 đều trống; 150 layer pairs chưa được chấm; cả 30 tolerance functional PENDING; bảng live validation không có dòng dữ liệu. Không tính IAA từ ô trống và không coi template là kết quả. M025 expert finalization vẫn giữ nguyên, không bị mở lại.

Bước tiếp theo: copy FIND_MISSING_VALIDATION_EVIDENCE.py vào repository Windows và chạy:
python .\FIND_MISSING_VALIDATION_EVIDENCE.py --root .
Gửi lại MISSING_VALIDATION_EVIDENCE\MISSING_VALIDATION_EVIDENCE.zip. Script tìm mọi vị trí trong chính root repository, kể cả file ngoài thư mục outputs/reports chuẩn; không gọi API, không sửa source. Raster chỉ được liệt kê đường dẫn/dung lượng, không tự đóng gói. Nếu dữ liệu thực nghiệm ở checkout khác, chạy với --root đúng checkout chứa kết quả. Không chạy lại model trước khi xác định dữ liệu cũ có còn hay không.

Nếu xác nhận chưa từng có LASR/functional/live runs thì phải lập kế hoạch mới theo dữ liệu và human gates còn thiếu; không dùng bản draft để suy ra rằng thực nghiệm đã chạy. Manuscript hiện hành cần chỉnh phạm vi để không nói prospective65/matched40/full-AOI đã được hoàn thành khi chưa có bằng chứng.
