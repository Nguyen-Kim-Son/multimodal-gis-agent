# Revision coverage — current evidence, not a completion certificate

| ID | Requirement | Status | Next action |
|---|---|---|---|
| R1-1 | Multimodal ingestion / scope | PARTIALLY_ADDRESSED | Integrate supplementary results and narrow title/abstract/scope; no 40-intent parity, ASR or sketch accuracy claim. |
| R1-2a | LASR mathematical definitions | IMPLEMENTATION_AVAILABLE_NOT_VALIDATION | Integrate actual evidence definitions, equal-area coverage requirement, weights and hard gate; document missing-value policy and how each scale gets observations. |
| R1-2b | LASR ablation across 35 tasks | REPORTED_IN_PRIOR_DRAFT_NOT_REAUDITED | Export raw task-condition-repeat results and manifests; recompute task-level paired inference. No superiority claim. |
| R1-2c | LASR weight sensitivity | REPORTED_IN_PRIOR_DRAFT_NOT_REAUDITED | Export fixed weight grid and raw results; verify shared tasks/config, task-level CIs and Holm contrasts. |
| R1-3a | Independent GIS annotation / agreement | PARTIALLY_ADDRESSED | Acquire actual independent operation/layer annotations; M025 ratings do not substitute for benchmark operation-set IAA. |
| R1-3b | Functional equivalence | CODE_ONLY_IN_AVAILABLE_EXPORT | Export candidate/reference executable scripts, successful execution logs and aligned analytical outputs; score tolerances per task. |
| R1-4a | Hanoi full-AOI NDVI | NOT_VERIFIED_FROM_AVAILABLE_DATA | Export analytical NDVI raster plus AOI/mask, date/cloud/scale/projection settings; compute all valid pixels, quantiles and histogram. |
| R1-4b | Independent WorldCover/statistics baseline | NOT_VERIFIED_FROM_AVAILABLE_DATA | Identify independent product and epoch/legend/CRS matching; quantify differences and shared-data dependence. |
| R1-5 | Exact provider/model/API settings | M025_COMPLETE_OTHER_COHORTS_PENDING | Reconcile legacy/LASR/prospective cohort model IDs, dates, parameters, routes and actual returned IDs; no retrospective substitution. |
| R1-minor-1 | Figure 1 fonts and acronyms | MANUSCRIPT_SOURCE_REQUIRED | Use editable source; define DRP/SRA and remove unsupported empirical modality claims. |
| R1-minor-2 | Figure 4 replace stars | PARTIAL | Replace legacy stars using original task-level uncertainty, not M025 ordinal distributions as substitute. |
| R1-minor-3 | Figure 5 define n | MANUSCRIPT_SOURCE_REQUIRED | Verify actual scaling data and define n and repeated measurement units; do not claim general speed advantage. |
| R1-minor-4 | Table 4 composite definition | MANUSCRIPT_SOURCE_REQUIRED | Verify exact composite formula from executed evaluator and add footnote; never apply composite to MAP+GRAPHIC. |
| R1-minor-5 | Repo license/environment/instructions | PARTIAL | Produce coherent release README/license after author license decision, task IDs, rerun commands, environment and checksums. |
| EDITOR-DATA | Minimal data and public DOI | PARTIAL | Add underlying tables for all other claims and archive actual repository; no DOI invented. |
| EDITOR-COPYRIGHT | Figures 1/4 permissions | NOT_VERIFIED | Provide permission record or replace with source-licensed figures; include provenance/captions. |
| EDITOR-XREF | Figures 6/11 and Tables 1–3 cited | MANUSCRIPT_SOURCE_REQUIRED | Repair editable manuscript references and compile; verify final numbering. |
| EDITOR-FUNDING | Funding placement and role | DRAFT_TEXT_READY_AUTHOR_VERIFICATION | Remove body funding; add role statement to cover letter only if factually confirmed by authors. |
| R2-LANGUAGE | English clarity and terminology | M025_INSERT_EDITED_FULL_MANUSCRIPT_PENDING | Edit full source after results integrated; distinguish normalization, visual interpretation, analytical execution and uncertainty. |
| R2-ROBUSTNESS | Benchmark robustness / prospective scope | NOT_VERIFIED_FROM_AVAILABLE_DATA | Export raw outputs and frozen manifests for actual completed cohorts; label plans versus results; no new inference without locked configuration. |
| SUBMISSION | Clean manuscript / tracked / response letter | DRAFT_INSERTS_ONLY | Obtain current editable manuscript and complete reviewer letter; integrate validated results, compile and create clean/tracked versions. |