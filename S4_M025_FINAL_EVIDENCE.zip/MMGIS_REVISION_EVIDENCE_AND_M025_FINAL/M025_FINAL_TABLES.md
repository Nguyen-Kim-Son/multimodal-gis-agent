# M025 — điểm cuối do chuyên gia chốt

Mỗi hàng gồm 10 responses cho cùng một intent. Các cột 0/1/2 là số responses nhận mức điểm đó. Không gộp tiêu chí hoặc so sánh độ khó xuyên track.

| Model | Track | Tiêu chí | Điểm 0 | Điểm 1 | Điểm 2 | Bị cắt |
|---|---|---|---:|---:|---:|---:|
| google/gemini-2.5-flash | MAP | M1_spatial_evidence | 0 | 0 | 10 | 0 |
| google/gemini-2.5-flash | MAP | M2_cartographic_reading | 0 | 0 | 10 | 0 |
| google/gemini-2.5-flash | MAP | M3_quantization | 0 | 0 | 10 | 0 |
| google/gemini-2.5-flash | MAP | M4_population_answerability | 4 | 0 | 6 | 0 |
| google/gemini-2.5-flash | MAP | M5_flood_distinction | 0 | 0 | 10 | 0 |
| google/gemini-2.5-flash | GRAPHIC | G1_entities | 0 | 0 | 10 | 0 |
| google/gemini-2.5-flash | GRAPHIC | G2_conceptual_relationship | 0 | 10 | 0 | 0 |
| google/gemini-2.5-flash | GRAPHIC | G3_flood_distinction | 0 | 5 | 5 | 0 |
| google/gemini-2.5-flash | GRAPHIC | G4_answerability | 0 | 0 | 10 | 0 |
| openai/gpt-4.1 | MAP | M1_spatial_evidence | 0 | 0 | 10 | 0 |
| openai/gpt-4.1 | MAP | M2_cartographic_reading | 0 | 0 | 10 | 0 |
| openai/gpt-4.1 | MAP | M3_quantization | 0 | 4 | 6 | 0 |
| openai/gpt-4.1 | MAP | M4_population_answerability | 3 | 0 | 7 | 0 |
| openai/gpt-4.1 | MAP | M5_flood_distinction | 3 | 3 | 4 | 0 |
| openai/gpt-4.1 | GRAPHIC | G1_entities | 0 | 0 | 10 | 0 |
| openai/gpt-4.1 | GRAPHIC | G2_conceptual_relationship | 0 | 10 | 0 | 0 |
| openai/gpt-4.1 | GRAPHIC | G3_flood_distinction | 0 | 0 | 10 | 0 |
| openai/gpt-4.1 | GRAPHIC | G4_answerability | 0 | 0 | 10 | 0 |
| openai/gpt-5-mini | MAP | M1_spatial_evidence | 0 | 0 | 10 | 9 |
| openai/gpt-5-mini | MAP | M2_cartographic_reading | 0 | 0 | 10 | 9 |
| openai/gpt-5-mini | MAP | M3_quantization | 0 | 6 | 4 | 9 |
| openai/gpt-5-mini | MAP | M4_population_answerability | 6 | 0 | 4 | 9 |
| openai/gpt-5-mini | MAP | M5_flood_distinction | 8 | 1 | 1 | 9 |
| openai/gpt-5-mini | GRAPHIC | G1_entities | 0 | 0 | 10 | 0 |
| openai/gpt-5-mini | GRAPHIC | G2_conceptual_relationship | 0 | 1 | 9 | 0 |
| openai/gpt-5-mini | GRAPHIC | G3_flood_distinction | 0 | 0 | 10 | 0 |
| openai/gpt-5-mini | GRAPHIC | G4_answerability | 0 | 0 | 10 | 0 |
