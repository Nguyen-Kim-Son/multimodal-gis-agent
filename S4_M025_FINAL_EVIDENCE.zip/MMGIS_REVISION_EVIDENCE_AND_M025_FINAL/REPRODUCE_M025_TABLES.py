from pathlib import Path
import json,csv,collections
ROOT=Path(__file__).resolve().parent
S=ROOT/'source_records'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
a=read(S/'SCORER_1_INDEPENDENT_SCORES.json');b=read(S/'SCORER_2_INDEPENDENT_SCORES.json');d=read(S/'M025_ADJUDICATION_FOLLOWUP_RETURN__2.json');ref={(x['response_id'],x['criterion']):x for x in d['cases']};rub=read(S/'RUBRIC_REVIEWED_BYTES.json');rows=[]
for x in sorted(read(S/'IDENTITY_CROSSWALK.json'),key=lambda x:x['run_id']):
 for c in rub[x['track'].lower()]:
  cid=c['id'];rid=x['response_id'];v=a['ratings'][rid]['criteria'][cid];w=b['ratings'][rid]['criteria'][cid];adj=ref.get((rid,cid))
  if adj:score=adj['adjudication']['agreed_score']
  else:assert v['score']==w['score'];score=v['score']
  rows.append((x['run_id'],cid,score))
expected=read(ROOT/'M025_FINAL_SCORES_LONG.json');assert rows==[(r['run_id'],r['criterion'],r['final_score']) for r in expected];assert len(rows)==270
for r in read(ROOT/'M025_DISTRIBUTION_BY_MODEL_TRACK_CRITERION.json'):
 values=[x['final_score'] for x in expected if (x['model'],x['track'],x['criterion'])==(r['model'],r['track'],r['criterion'])];assert len(values)==10
 for score in [0,1,2]:assert values.count(score)==r[f'n_score_{score}']
print('PASS 270 final scores and 27 criterion distribution rows reproduced from source submissions; MODEL_CALLS_ADDED 0')
