# M025 đã tổng hợp; toàn bộ revision chưa hoàn tất

## Đã thực hiện
- Dùng nguyên điểm cuối trong M025_ADJUDICATION_FOLLOWUP_RETURN (2).json, theo tác giả xác nhận hai chuyên gia đã chốt.
- Xuất 270 điểm cuối, 27 hàng phân phối theo model/track/tiêu chí, hai biểu đồ riêng PNG/SVG/PDF, raw results, input/rubric hashes, điểm gốc và lịch sử đối soát.
- Kappa/đồng thuận dùng hai bộ điểm trước đối soát, không dùng điểm đồng thuận để tạo agreement giả.
- 51 COMPLETE + 9 TRUNCATED; tất cả output bị cắt vẫn được giữ. Không thêm inference. Tổng M025 vẫn 63 attempts (60 primary +3 preflight).
- Xuất nội dung tiếng Anh cho methods/results/limitations, draft phản hồi và ma trận 21 nhóm yêu cầu.
- Không ghi đè manuscript hay artifact freeze cũ. Đây là gói tích hợp phân tích, chưa phải bản manuscript clean/Track Changes hoàn chỉnh.

## Kết quả cần đọc đúng
Bảng và biểu đồ phản ánh quyết định cuối của panel, kể cả các lý do chưa hoàn toàn nhất quán với anchor. Việc tác giả chốt điểm không xoá các hạn chế này. Hai chuyên gia khai báo không dùng gợi ý AI; nhãn nguồn ở file cũ chưa được giải thích, nên không gọi đó là AI-assisted như một sự kiện đã xác nhận, cũng không khẳng định tính độc lập đã được kiểm chứng hoàn toàn.

M025 là một intent; không coi 60 generations là 60 tác vụ GIS. MAP và GRAPHIC không ngang hàng thông tin. Không tổng hợp điểm chung, không kiểm định modality effect, không suy luận năng lực tổng quát, không tuyên bố hoàn tất normalization/end-to-end evaluation. ASR và sketch accuracy chưa được đo.

## Bước thực thi tiếp theo tại repository Windows
Giải nén gói, copy EXPORT_REVISION_EVIDENCE.py vào:
C:\Users\sonnk\MMGIS-Bench\MMGIS-Bench-Revision-1.0.1
Trong PowerShell của repository, chạy:

python .\EXPORT_REVISION_EVIDENCE.py --root .

Script không dùng API key, không gọi model, không sửa source. Nó xuất REVISION_EVIDENCE_EXPORT\MMGIS_REVISION_EVIDENCE.zip và manifest. Kiểm tra danh sách file trước khi gửi, rồi cung cấp ZIP đó để tiếp tục tính lại LASR/sensitivity, rà functional/live outputs và tích hợp manuscript hiện hành. Nếu file bị bỏ do dung lượng, manifest ghi rõ; không tự coi dữ liệu bị bỏ là thiếu trên máy tác giả. Raster TIFF không được tự đóng gói trong lượt này.

Chưa cần chạy thêm model. Chưa dùng các model/endpoint cũ cho một thí nghiệm mới nếu chưa kiểm tra quyền truy cập và cấu hình.

## Thứ tự xử lý sau khi có bằng chứng
1. LASR35: đối chiếu raw task-condition-repeat, model/config và freeze; tính lại paired task-level summaries, CIs, Holm contrasts, weight grid. Không chọn trọng số sau khi xem kết quả. Nếu không có dữ liệu thật, báo chưa có thay vì tạo output giả.
2. Annotation/function: kiểm tra nhãn GIS độc lập cho operation/layer, các script và execution outputs theo tolerance; không dùng M025 output ratings thay thế.
3. Hanoi: cần raster phân tích, AOI/mask, projection/scale/date/cloud config; full-AOI NDVI và baseline độc lập cho thống kê land cover.
4. Manuscript: lấy bản editable mới nhất và toàn văn thư quyết định/reviewer 2 nếu chưa có. Bản PDF tiền kết quả được tìm thấy có các cam kết/chỗ chờ số liệu chưa được xác minh (prospective65/combined100, matched40, functional subset). Không biến kế hoạch thành kết quả.
5. Editorial: clean/tracked/response letter, cross-references, funding placement, figure rights, complete minimal data archive and actual DOI. Không tự cấp license hoặc tạo DOI.

## Tái lập và kiểm tra
python .\REPRODUCE_M025_TABLES.py
Chạy từ gói đã giải nén; xác nhận tái lập 270 scores và 27 distribution rows từ source_records. CHECKSUMS.json chứa hashes mọi file trong gói, trừ chính checksum file. Phần raw results và identity crosswalk dành cho tác giả; chỉ công bố sau khi rà riêng tư và điều khoản dữ liệu.
