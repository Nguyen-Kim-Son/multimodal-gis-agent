"""Read-only, offline evidence export. No API calls, credentials or source changes."""
from pathlib import Path
import argparse,hashlib,json,zipfile,re,sys
ALLOWED={'.json','.jsonl','.csv','.tsv','.txt','.md','.yaml','.yml','.toml','.py','.ps1','.tex','.bib','.docx','.pdf','.png','.svg','.log'}
ROOTS=['outputs','results','runs','reports','experiments','configs','lasr','lasr_validation','revision','functional_eval','live_validation','annotation_agreement','evaluation','data/v1/annotations','data/v1/review','data/v1/lasr','data/v1/live','data/v1/functional','docs','paper','manuscript','prompts','tasks']
EXCLUDE={'.git','.venv','venv','node_modules','__pycache__','dist','cache','credentials','secrets'}
def export(root,out,max_file_mb=50,max_total_mb=400):
 root=root.resolve();out=out.resolve();out.mkdir(parents=True,exist_ok=True);entries=[];omit=[];seen=set();total=0;files=[]
 for part in ROOTS:
  folder=root/part
  if folder.is_dir():files.extend(folder.rglob('*'))
 files.extend(p for p in root.iterdir() if p.is_file() and p.suffix.lower() in {'.docx','.tex','.bib','.pdf'})
 for name in ['pyproject.toml','requirements.txt','requirements-lock.txt','environment.yml','LICENSE','LICENSE.txt','README.md']:
  if (root/name).is_file():files.append(root/name)
 for p in sorted(files):
  if not p.is_file() or p.is_symlink() or p in seen:continue
  seen.add(p);rel=p.relative_to(root)
  if out==p or out in p.parents or any(x.lower() in EXCLUDE for x in rel.parts):continue
  if p.suffix.lower() not in ALLOWED and p.name not in ['LICENSE']:continue
  if any(x in p.name.lower() for x in ['.env','credential','secret','token_cache','service_account','service-account','api_key','apikey','auth.json']):omit.append({'path':str(rel),'reason':'sensitive filename'});continue
  size=p.stat().st_size
  if size>max_file_mb*1024**2 or total+size>max_total_mb*1024**2:omit.append({'path':str(rel),'reason':'size limit','size_bytes':size});continue
  raw=p.read_bytes()
  # Conservative evidence preservation: skip, never rewrite a suspected credential.
  if re.search(rb'(?:sk-or-v1-|sk-proj-|AIza)[A-Za-z0-9_-]{20,}|-----BEGIN (?:RSA |EC )?PRIVATE KEY-----',raw):omit.append({'path':str(rel),'reason':'possible credential bytes; inspect locally'});continue
  entries.append({'path':rel.as_posix(),'size_bytes':size,'sha256':hashlib.sha256(raw).hexdigest().upper()});total+=size
 manifest={'artifact_id':'MMGIS_REVISION_EXISTING_EVIDENCE_EXPORT','mode':'OFFLINE_READ_ONLY_NO_INFERENCE','root_name':root.name,'files':entries,'omitted':omit,'total_bytes':total,'analytical_rasters_excluded':'TIFFs not exported automatically; list analytical raster paths separately when requested.','privacy_note':'Filename and token-pattern exclusions are precautionary, not a guarantee. Review ZIP contents before sharing; do not include API keys or unrelated private files.'}
 zpath=out/'MMGIS_REVISION_EVIDENCE.zip'
 with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
  for e in entries:z.write(root/e['path'],e['path'])
  z.writestr('REVISION_EVIDENCE_EXPORT_MANIFEST.json',json.dumps(manifest,indent=2))
 (out/'REVISION_EVIDENCE_EXPORT_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
 print('EXPORTED_FILES',len(entries));print('OMITTED_FILES',len(omit));print('NEW_MODEL_CALLS',0);print('OUTPUT',zpath);return manifest
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path.cwd());p.add_argument('--output-dir',type=Path);p.add_argument('--max-file-mb',type=float,default=50);p.add_argument('--max-total-mb',type=float,default=400);a=p.parse_args();export(a.root,a.output_dir or a.root/'REVISION_EVIDENCE_EXPORT',a.max_file_mb,a.max_total_mb)
