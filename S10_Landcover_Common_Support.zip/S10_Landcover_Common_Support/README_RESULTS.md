# Common-support land-cover comparison

- Common valid pixels: 12216988
- Overall agreement: 0.3949
- Expected agreement: 0.2282
- Cohen's kappa: 0.2160
- Matrix orientation: rows = WorldCover, columns = MODIS.
- This is product-to-product agreement, not accuracy against independent ground truth.
