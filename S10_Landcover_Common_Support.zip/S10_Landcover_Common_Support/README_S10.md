# S10 — Common-support land-cover comparison

- WorldCover 2021 (10 m) vs MODIS MCD12Q1 (500 m), full study bbox.
- Common valid pixels: 12,216,988.
- Overall agreement: 0.3949; expected agreement: 0.2282; Cohen's kappa: 0.2160.
- Matrix rows = WorldCover, columns = MODIS; product-to-product agreement, not accuracy against ground truth.
- Crosswalk: `config/crosswalk.json` (approved 2026-10-23, reviewed by Hueltm and Nguyen Kim Son).
- The MODIS product contains no forest class in this extent, so WorldCover tree cover has no MODIS counterpart.
