#!/usr/bin/env python3
"""Common-support land-cover comparison.

Reprojects MODIS to the WorldCover grid, maps both products through an approved
crosswalk, and reports a confusion matrix, overall agreement, Cohen's kappa,
user's/producer's accuracy and area fractions on the common valid support.

This is product-to-product agreement, not classification accuracy against ground truth.
"""
import argparse
import csv
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


def now():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def load_crosswalk(path):
    data = json.load(open(path, encoding="utf-8"))
    mapping = data.get("mapping") or data
    if "worldcover" not in mapping or "modis" not in mapping:
        raise SystemExit("crosswalk must contain mapping.worldcover and mapping.modis")
    wc = {int(k): str(v) for k, v in mapping["worldcover"].items()}
    mo = {int(k): str(v) for k, v in mapping["modis"].items()}
    return wc, mo, data


def analyse_arrays(wc, mod, wc_map, mod_map, pixel_area_m2):
    classes = sorted(set(wc_map.values()) | set(mod_map.values()))
    index = {c: i for i, c in enumerate(classes)}
    wc_flat = np.asarray(wc).ravel()
    mod_flat = np.asarray(mod).ravel()
    valid = np.array([(int(a) in wc_map) and (int(b) in mod_map) for a, b in zip(wc_flat, mod_flat)])
    a = wc_flat[valid].astype(np.int64)
    b = mod_flat[valid].astype(np.int64)
    n = len(a)
    if n == 0:
        raise SystemExit("no common valid pixels after crosswalk masking")
    ai = np.array([index[wc_map[int(x)]] for x in a], dtype=np.int32)
    bi = np.array([index[mod_map[int(x)]] for x in b], dtype=np.int32)
    cm = np.zeros((len(classes), len(classes)), dtype=np.int64)
    np.add.at(cm, (ai, bi), 1)
    row = cm.sum(axis=1).astype(float)
    col = cm.sum(axis=0).astype(float)
    diag = np.diag(cm).astype(float)
    with np.errstate(divide="ignore", invalid="ignore"):
        users = np.where(row > 0, diag / row, np.nan)
        producers = np.where(col > 0, diag / col, np.nan)
    po = float(diag.sum() / n)
    pe = float((row * col).sum() / (n * n))
    kappa = (po - pe) / (1 - pe) if pe < 1 else float("nan")
    area_km2 = cm * pixel_area_m2 / 1e6
    wc_area = row * pixel_area_m2 / 1e6
    mod_area = col * pixel_area_m2 / 1e6
    return {
        "classes": classes,
        "n_common_pixels": int(n),
        "confusion_matrix": cm.tolist(),
        "overall_agreement": po,
        "expected_agreement": pe,
        "cohen_kappa": kappa,
        "user_accuracy": users.tolist(),
        "producer_accuracy": producers.tolist(),
        "worldcover_area_km2": wc_area.tolist(),
        "modis_area_km2": mod_area.tolist(),
        "worldcover_fraction": (wc_area / wc_area.sum()).tolist(),
        "modis_fraction": (mod_area / mod_area.sum()).tolist(),
        "cell_area_km2": area_km2.tolist(),
    }


def write_outputs(result, out_prefix):
    out_prefix = Path(out_prefix); out_prefix.parent.mkdir(parents=True, exist_ok=True)
    classes = result["classes"]
    (Path(str(out_prefix) + ".json")).write_text(json.dumps(result, indent=2), encoding="utf-8")
    with open(str(out_prefix) + "_matrix.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(["worldcover\\modis"] + classes)
        for c, row in zip(classes, result["confusion_matrix"]):
            w.writerow([c] + row)
    with open(str(out_prefix) + "_summary.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["class", "worldcover_fraction", "modis_fraction", "user_accuracy", "producer_accuracy", "worldcover_km2", "modis_km2"])
        for i, c in enumerate(classes):
            w.writerow([c, result["worldcover_fraction"][i], result["modis_fraction"][i],
                        result["user_accuracy"][i], result["producer_accuracy"][i],
                        result["worldcover_area_km2"][i], result["modis_area_km2"][i]])
    lines = [r"\begin{tabular}{lrrrr}", r"\toprule",
             r"Class & WorldCover (\%) & MODIS (\%) & User's acc. & Producer's acc.\\", r"\midrule"]
    for i, c in enumerate(classes):
        lines.append(f"{c.replace('_',' ')} & {100*result['worldcover_fraction'][i]:.2f} & {100*result['modis_fraction'][i]:.2f} & {result['user_accuracy'][i]:.3f} & {result['producer_accuracy'][i]:.3f}\\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (Path(str(out_prefix) + "_table.tex")).write_text("\n".join(lines) + "\n", encoding="utf-8")
    with open(str(out_prefix) + "_README.md", "w", encoding="utf-8") as fh:
        fh.write(f"""# Common-support land-cover comparison

- Common valid pixels: {result['n_common_pixels']}
- Overall agreement: {result['overall_agreement']:.4f}
- Expected agreement: {result['expected_agreement']:.4f}
- Cohen's kappa: {result['cohen_kappa']:.4f}
- Matrix orientation: rows = WorldCover, columns = MODIS.
- This is product-to-product agreement, not accuracy against independent ground truth.
""")


def self_test():
    wc_map = {10: "tree_forest", 30: "grass_shrub", 40: "cropland", 50: "built_up", 80: "water", 90: "wetland", 60: "bare_other"}
    mo_map = {1: "tree_forest", 6: "grass_shrub", 12: "cropland", 13: "built_up", 17: "water", 11: "wetland", 16: "bare_other"}
    wc = np.array([[10,10,50,50],[30,30,50,50],[40,40,80,80],[40,40,80,80]], dtype=np.uint8)
    mo = np.array([[1,1,13,13],[6,6,13,13],[12,12,17,17],[12,12,17,17]], dtype=np.uint8)
    r = analyse_arrays(wc, mo, wc_map, mo_map, 100.0)
    print(json.dumps({k: r[k] for k in ("n_common_pixels","overall_agreement","cohen_kappa")}, indent=2))
    assert r["n_common_pixels"] == 16
    assert 0 <= r["overall_agreement"] <= 1
    print("self-test PASS")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--worldcover")
    ap.add_argument("--modis")
    ap.add_argument("--crosswalk")
    ap.add_argument("--out-prefix", default="results/landcover_common_support")
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        self_test(); return
    if not (args.worldcover and args.modis and args.crosswalk):
        raise SystemExit("--worldcover, --modis and --crosswalk are required")
    try:
        import rasterio
        from rasterio.warp import reproject, Resampling
    except Exception as exc:
        raise SystemExit(f"rasterio is required: {exc}")
    wc_map, mo_map, cw = load_crosswalk(args.crosswalk)
    with rasterio.open(args.worldcover) as ds_wc, rasterio.open(args.modis) as ds_mo:
        wc = ds_wc.read(1)
        mod_on_wc = np.zeros((ds_wc.height, ds_wc.width), dtype=ds_mo.read(1).dtype)
        reproject(
            source=rasterio.band(ds_mo, 1), destination=mod_on_wc,
            src_transform=ds_mo.transform, src_crs=ds_mo.crs,
            dst_transform=ds_wc.transform, dst_crs=ds_wc.crs,
            resampling=Resampling.nearest, src_nodata=ds_mo.nodata, dst_nodata=0,
        )
        pixel_area = abs(ds_wc.transform.a * ds_wc.transform.e)
        result = analyse_arrays(wc, mod_on_wc, wc_map, mo_map, pixel_area)
        result.update({
            "generated_utc": now(),
            "worldcover": {"path": str(Path(args.worldcover).resolve()), "shape": [ds_wc.height, ds_wc.width], "crs": str(ds_wc.crs), "res": [ds_wc.transform.a, ds_wc.transform.e]},
            "modis": {"path": str(Path(args.modis).resolve()), "shape": [ds_mo.height, ds_mo.width], "crs": str(ds_mo.crs), "res": [ds_mo.transform.a, ds_mo.transform.e]},
            "crosswalk": {"path": str(Path(args.crosswalk).resolve()), "approved_utc": cw.get("approved_utc"), "reviewed_by": cw.get("reviewed_by")},
            "note": "Rows = WorldCover, columns = MODIS. Product-to-product agreement, not accuracy against ground truth.",
        })
    write_outputs(result, args.out_prefix)
    print(json.dumps({k: result[k] for k in ("n_common_pixels","overall_agreement","expected_agreement","cohen_kappa")}, indent=2))
    print("wrote", args.out_prefix)


if __name__ == "__main__":
    main()
