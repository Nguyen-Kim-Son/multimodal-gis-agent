# 0.8.8 final weight-sensitivity statistics
Offline only: no API calls. Uses the frozen 385-result run (35 paired tasks x 11 prespecified weights).
Outputs 10,000 task bootstrap CIs, 10 paired Wilcoxon tests, rank-biserial effects,
Holm correction across all 10 comparisons, publication table and 300-dpi sensitivity figure. Reference weights remain 0.40/0.40/0.20.
