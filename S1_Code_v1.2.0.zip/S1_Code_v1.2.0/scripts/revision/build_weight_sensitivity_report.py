from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import wilcoxon
import matplotlib.pyplot as plt
REF=(.4,.4,.2)
def key(a,b,c): return f"{a:.4f}/{b:.4f}/{c:.4f}"
def boot(x,n,seed):
 x=np.asarray(x,float);g=np.random.default_rng(seed);v=np.array([g.choice(x,len(x),replace=True).mean() for _ in range(n)])
 return x.mean(),np.quantile(v,.025),np.quantile(v,.975)
def rb(d):
 d=np.asarray(d,float);d=d[d!=0]
 if not len(d):return 0.
 r=pd.Series(abs(d)).rank(method="average").to_numpy();p=r[d>0].sum();q=r[d<0].sum();return (p-q)/(p+q)
def holm(p):
 p=np.asarray(p);o=np.argsort(p);a=np.empty(len(p));last=0.
 for j,i in enumerate(o):last=max(last,(len(p)-j)*p[i]);a[i]=min(1,last)
 return a
def integrity(d):
 x=[]
 if len(d)!=385:x.append(f"expected 385 rows, got {len(d)}")
 if d.task_id.nunique()!=35:x.append("expected 35 tasks")
 if len(d[["weight_local","weight_regional","weight_global"]].drop_duplicates())!=11:x.append("expected 11 weights")
 if d[["weight_tag","task_id","repeat"]].duplicated().any():x.append("duplicates")
 if not (d.groupby("weight_tag").task_id.nunique()==35).all():x.append("incomplete pairing")
 if d.error.fillna("").astype(str).str.strip().ne("").any():x.append("errors")
 if d.truncated.fillna(False).astype(bool).any():x.append("truncation")
 for c in ["request_max_tokens","request_temperature","request_timeout"]:
  if d[c].nunique(dropna=False)!=1:x.append("control mismatch "+c)
 return x
def main():
 p=argparse.ArgumentParser();p.add_argument("--results",required=True);p.add_argument("--output",required=True);p.add_argument("--bootstrap",type=int,default=10000);p.add_argument("--seed",type=int,default=20260915);a=p.parse_args()
 out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
 d=pd.DataFrame([json.loads(x) for x in Path(a.results).read_text(encoding="utf8").splitlines() if x.strip()])
 bad=integrity(d);(out/"integrity_check.txt").write_text("PASS\n" if not bad else "FAIL\n"+"\n".join(bad)); 
 if bad:raise SystemExit("; ".join(bad))
 d["weight_key"]=[key(*x) for x in d[["weight_local","weight_regional","weight_global"]].to_numpy()]
 order=list(d.weight_key.drop_duplicates());ref=key(*REF)
 S=[]
 for j,k in enumerate(order):
  g=d[d.weight_key==k];m,l,h=boot(g.overall_score,a.bootstrap,a.seed+j);r=g.iloc[0]
  S.append([k,r.weight_local,r.weight_regional,r.weight_global,len(g),m,l,h,g.passed.mean()])
 s=pd.DataFrame(S,columns=["weight_key","local","regional","global","n_tasks","mean_score","ci_low","ci_high","pass_rate"]);s.to_csv(out/"weight_task_summary.csv",index=False)
 w=d.pivot(index="task_id",columns="weight_key",values="overall_score").sort_index();P=[]
 for j,k in enumerate([x for x in order if x!=ref]):
  z=(w[ref]-w[k]).to_numpy();m,l,h=boot(z,a.bootstrap,a.seed+100+j)
  try:W,pv=wilcoxon(z,zero_method="wilcox",alternative="two-sided",method="auto")
  except ValueError:W,pv=0,1
  P.append([k,len(z),m,l,h,W,pv,rb(z),(z>0).sum(),(z==0).sum(),(z<0).sum()])
 q=pd.DataFrame(P,columns=["comparator","n_tasks","mean_difference_ref_minus_comparator","ci_low","ci_high","wilcoxon_W","p_raw","rank_biserial","ref_wins","ties","ref_losses"])
 q["p_holm_10"]=holm(q.p_raw);q["significant_holm_0_05"]=q.p_holm_10<.05;q.to_csv(out/"paired_reference_comparisons.csv",index=False)
 pm=q.set_index("comparator")
 pub=s.copy();pub["Mean score (95% bootstrap CI)"]=pub.apply(lambda r:f"{r.mean_score:.3f} ({r.ci_low:.3f}, {r.ci_high:.3f})",axis=1)
 pub["Delta ref-config"]=pub.weight_key.map(pm.mean_difference_ref_minus_comparator);pub["Holm p"]=pub.weight_key.map(pm.p_holm_10);pub["Rank-biserial"]=pub.weight_key.map(pm.rank_biserial)
 pub[["weight_key","n_tasks","Mean score (95% bootstrap CI)","Delta ref-config","Holm p","Rank-biserial"]].to_csv(out/"publication_table_weight_sensitivity.csv",index=False)
 x=np.arange(len(s));m=s.mean_score.to_numpy();lo=s.ci_low.to_numpy();hi=s.ci_high.to_numpy()
 fig,ax=plt.subplots(figsize=(9.2,5.2));ax.errorbar(x,m,yerr=np.vstack([m-lo,hi-m]),fmt="o",capsize=4);ax.axhline(float(s[s.weight_key==ref].mean_score.iloc[0]),ls="--",lw=1);ax.set_xticks(x,s.weight_key,rotation=45,ha="right");ax.set_ylabel("Mean overall score (95% task-bootstrap CI)");ax.set_xlabel("LASR weights (local / regional / global)");ax.set_title("LASR weight-sensitivity robustness analysis (35 paired tasks)");ax.grid(axis="y",alpha=.25);fig.tight_layout();fig.savefig(out/"figure_weight_sensitivity.png",dpi=300,bbox_inches="tight");plt.close(fig)
 r=s[s.weight_key==ref].iloc[0];best=s.loc[s.mean_score.idxmax()];rng=s.mean_score.max()-s.mean_score.min();mx=q.mean_difference_ref_minus_comparator.abs().max();ns=int(q.significant_holm_0_05.sum())
 lines=["LASR WEIGHT-SENSITIVITY STATISTICAL REPORT","Inferential unit: unique task (n=35).","Bootstrap: 10,000 task resamples.","Reference: 0.40/0.40/0.20. Paired two-sided Wilcoxon; rank-biserial effects; Holm correction across 10 comparisons.","",f"Reference mean={r.mean_score:.4f}, 95% CI [{r.ci_low:.4f}, {r.ci_high:.4f}].",f"Highest descriptive mean={best.weight_key}: {best.mean_score:.4f} (not used to redefine reference).",f"Mean-score range across grid={rng:.4f}; maximum absolute paired mean difference from reference={mx:.4f}; Holm-significant comparisons={ns}/10.",""]
 for _,z in q.iterrows():lines.append(f"Ref vs {z.comparator}: Δ={z.mean_difference_ref_minus_comparator:.4f}, 95% CI [{z.ci_low:.4f},{z.ci_high:.4f}], W={z.wilcoxon_W:.1f}, raw p={z.p_raw:.6g}, Holm p={z.p_holm_10:.6g}, r_rb={z.rank_biserial:.3f}, W/T/L={int(z.ref_wins)}/{int(z.ties)}/{int(z.ref_losses)}.")
 (out/"statistical_summary.txt").write_text("\n".join(lines)+"\n",encoding="utf8")
 interp=("None of the 10 paired comparisons remained significant after Holm correction." if ns==0 else f"{ns} of 10 paired comparisons remained significant after Holm correction.")
 print("\n".join(lines))
if __name__=="__main__":main()
