# S1 Code — MMGIS-Bench v1.2.0

Revision code for the benchmark, controlled LASR prompt-policy variants, and the 11-setting weight-sensitivity runner.

## Contents
- `lasr/strategy.py`, `lasr/weights.py` — four LASR variants and the prespecified weight grid.
- `revision/lasr_runner.py` — four-condition ablation runner.
- `revision/weight_runner.py` — 11-setting weight-sensitivity runner.
- `benchmark/`, `models/`, `evaluation/`, `tasks/`, `configs/`, `scripts/` — benchmark stack.

## Implementation boundary
The released LASR code implements the scale partition as a prompt-level policy. `lasr/strategy.py` builds the treatment prompt; the six compatibility terms in the manuscript define the intended semantics but are not separately calibrated numeric predictors in this code.

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q
python scripts/revision/run_lasr_ablation.py --config configs/revision/lasr_revision.yaml
python scripts/revision/run_lasr_weight_sensitivity.py --config configs/revision/lasr_revision.yaml
```
