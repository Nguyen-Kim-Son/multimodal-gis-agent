"""Usage: python recompute_ndvi.py PATH_TO_ANALYTICAL_TIFF --output audit_output
Offline audit. Dependencies: numpy, Pillow, matplotlib. Does not call GEE or models.
"""
import argparse, hashlib, json, csv
from pathlib import Path
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

p=argparse.ArgumentParser();p.add_argument('raster',type=Path);p.add_argument('--output',type=Path,default=Path('audit_output'));args=p.parse_args()
args.output.mkdir(parents=True,exist_ok=True)
im=Image.open(args.raster);a=np.asarray(im);assert a.ndim==2
v=a[np.isfinite(a)].astype(np.float64);assert v.size
h,b=np.histogram(v,np.linspace(-1,1,101))
stats={'sha256':hashlib.sha256(args.raster.read_bytes()).hexdigest(),'width':im.width,'height':im.height,'finite_pixels':int(v.size),'nonfinite_cells':int((~np.isfinite(a)).sum()),'mean':float(v.mean()),'median':float(np.median(v)),'population_std_ddof0':float(v.std()),'min':float(v.min()),'max':float(v.max()),'percentiles_5_10_25_50_75_90_95':np.percentile(v,[5,10,25,50,75,90,95]).tolist(),'underflow_lt_minus_020':int((v<-.2).sum()),'overflow_ge_090':int((v>=.9).sum()),'outside_physical_ndvi_domain':int(((v < -1)|(v > 1)).sum()),'numpy_version':np.__version__,'note':'Finite-value audit only. No claim of verified cloud masking, GEE origin or polygon coverage.'}
(args.output/'statistics.json').write_text(json.dumps(stats,indent=2))
with (args.output/'histogram.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['bin_lower','bin_upper','pixel_count']);w.writerows(zip(b[:-1],b[1:],h))
fig,ax=plt.subplots(figsize=(7,3.9));ax.bar(b[:-1],h,width=.02,align='edge',color='#28799b',edgecolor='white',linewidth=.2)
ax.axvline(v.mean(),color='#bd3035',ls='--',lw=1.3,label=f'Mean {v.mean():.4f}')
ax.axvline(np.median(v),color='#397d35',ls=':',lw=1.5,label=f'Median {np.median(v):.4f}')
ax.set(xlabel='NDVI',ylabel='Finite pixel count',xlim=(-1,1));ax.ticklabel_format(axis='y',style='sci',scilimits=(0,0));ax.legend(frameon=False,fontsize=9);ax.text(.02,.96,f'N = {v.size:,}\nSD = {v.std():.4f}',transform=ax.transAxes,va='top',fontsize=9);ax.spines[['top','right']].set_visible(False);fig.tight_layout()
for ext in ['png','pdf','tif']:fig.savefig(args.output/('hanoi_ndvi_full_domain.'+ext),dpi=300)
print(json.dumps(stats,indent=2))
