// GEE Provenance Script for Hanoi NDVI 2023
var aoi = ee.Geometry.Rectangle([105.70, 20.90, 106.00, 21.25], 'EPSG:4326', false);
var s2Col = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
  .filterBounds(aoi)
  .filterDate('2023-01-01', '2024-01-01')
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20));

function maskSCL(img) {
  var scl = img.select('SCL');
  var valid = scl.neq(0).and(scl.neq(1)).and(scl.neq(3))
    .and(scl.neq(8)).and(scl.neq(9)).and(scl.neq(10)).and(scl.neq(11));
  return img.updateMask(valid);
}

var composite = s2Col.map(maskSCL).median();
var ndvi = composite.normalizedDifference(['B8', 'B4']).rename('NDVI').clip(aoi);

Export.image.toDrive({
  image: ndvi,
  description: 'HANOI_NDVI_2023_10M_ANALYTICAL_JOB',
  fileNamePrefix: 'Hanoi_NDVI_2023_10m_analytical',
  scale: 10,
  crs: 'EPSG:32648',
  crsTransform: [10.0, 0.0, 572620.0, 0.0, -10.0, 2350150.0],
  maxPixels: 1e10
});
