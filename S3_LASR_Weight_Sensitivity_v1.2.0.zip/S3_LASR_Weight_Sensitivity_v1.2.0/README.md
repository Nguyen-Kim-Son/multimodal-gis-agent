# S3 Data — LASR weight sensitivity v1.2.0

385 task-level records = 35 tasks × 11 prespecified settings; one observation per task and setting. Reference 0.40/0.40/0.20 mean is 0.547 (95% CI 0.451–0.638); grid range 0.515–0.587; 0/10 Holm-adjusted comparisons significant.

The 0.547 reference is a one-run-per-task sensitivity cohort, separate from the 0.568 three-repeat reference in S2. Raw model response text is not included.
