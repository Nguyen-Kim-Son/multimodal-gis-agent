# S3 Data — LASR weight sensitivity v1.1.0

385 task-level records = 35 tasks × 11 prespecified settings; one observation per task and setting. The reference 0.40/0.40/0.20 mean is 0.547 (95% CI 0.451–0.638); the grid range is 0.515–0.587; 0/10 Holm-adjusted comparisons are significant.

The 0.547 reference is a one-run-per-task sensitivity cohort. It is separate from the 0.568 three-repeat reference in S2 and is not expected to be numerically identical. Raw model response text is not included.
