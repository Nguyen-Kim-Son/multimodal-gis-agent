from __future__ import annotations

import argparse
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from revision.weight_runner import run_weight_sensitivity


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/revision/lasr_revision.yaml")
    a = p.parse_args()

    config_path = Path(a.config)
    if not config_path.is_absolute():
        config_path = ROOT / config_path

    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    result = run_weight_sensitivity(cfg, project_root=ROOT)
    print(result)


if __name__ == "__main__":
    main()
