from __future__ import annotations

import argparse, ast, json, math, random, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd

try:
    from scipy.stats import wilcoxon
except Exception:
    wilcoxon = None

try:
    import matplotlib.pyplot as plt
except Exception:
    plt = None


def parse_scores(v):
    if isinstance(v,dict): return v
    if not isinstance(v,str): return {}
    try:
        x=ast.literal_eval(v); return x if isinstance(x,dict) else {}
    except Exception: return {}


def bootstrap_mean_ci(values,seed=2026,n=10000):
    vals=[float(x) for x in values if pd.notna(x)]
    if not vals: return (float('nan'),float('nan'))
    rng=random.Random(seed); means=[]
    for _ in range(n): means.append(sum(rng.choice(vals) for _ in vals)/len(vals))
    means.sort(); return means[int(.025*(n-1))],means[int(.975*(n-1))]


def task_means(df,group_col):
    metric_cols=[c for c in ['overall_score','operation_precision','operation_recall','operation_f1','workflow_order','hallucinated_operation_rate'] if c in df]
    return df.groupby([group_col,'task_id'],as_index=False)[metric_cols].mean(numeric_only=True)


def expand_scores(df):
    df=df.copy(); df['scores_dict']=df['scores'].map(parse_scores)
    names=sorted({k for d in df['scores_dict'] for k in d})
    for n in names: df[n]=df['scores_dict'].map(lambda d:d.get(n))
    return df


def summarize(df,group_col):
    t=task_means(df,group_col); rows=[]
    metrics=[c for c in t.columns if c not in {group_col,'task_id'}]
    for key,g in t.groupby(group_col):
        row={group_col:key,'n_tasks':g.task_id.nunique()}
        for m in metrics:
            vals=g[m].dropna().tolist(); lo,hi=bootstrap_mean_ci(vals)
            row[f'mean_{m}']=sum(vals)/len(vals) if vals else float('nan')
            row[f'ci95_low_{m}']=lo; row[f'ci95_high_{m}']=hi
        rows.append(row)
    return pd.DataFrame(rows)


def paired_tests(taskdf,baseline='full_lasr'):
    if wilcoxon is None: return pd.DataFrame()
    wide=taskdf.pivot(index='task_id',columns='condition',values='overall_score'); rows=[]
    if baseline not in wide: return pd.DataFrame()
    for other in wide.columns:
        if other==baseline: continue
        pair=wide[[baseline,other]].dropna(); diff=pair[baseline]-pair[other]
        if len(pair)==0: continue
        if (diff.abs()<1e-15).all(): stat,p=0.0,1.0
        else: stat,p=wilcoxon(pair[baseline],pair[other],zero_method='wilcox',alternative='two-sided')
        rows.append({'contrast':f'{baseline} - {other}','n_tasks':len(pair),'mean_difference':diff.mean(),'wilcoxon_stat':stat,'p_value':p})
    return pd.DataFrame(rows)


def main():
    p=argparse.ArgumentParser();p.add_argument('--run-dir',default='outputs/revision/lasr_revision_v1');p.add_argument('--output',default='reports/revision/lasr');a=p.parse_args()
    run=ROOT/a.run_dir; out=ROOT/a.output; out.mkdir(parents=True,exist_ok=True)
    results_path = run/'lasr_revision_results.jsonl'
    if not results_path.exists():
        raise FileNotFoundError(
            f"LASR ablation output not found: {results_path}\n"
            "Run scripts/revision/run_lasr_ablation.py successfully before building the report."
        )
    rows=[json.loads(x) for x in results_path.read_text(encoding='utf-8').splitlines() if x.strip()]
    df=expand_scores(pd.DataFrame(rows)); df.to_csv(out/'lasr_ablation_raw.csv',index=False)
    summ=summarize(df,'condition'); summ.to_csv(out/'lasr_ablation_summary.csv',index=False)
    t=task_means(df,'condition'); t.to_csv(out/'lasr_ablation_task_means.csv',index=False)
    paired_tests(t).to_csv(out/'lasr_ablation_paired_tests.csv',index=False)

    wpath=run/'lasr_weight_sensitivity.jsonl'
    if wpath.exists():
        wdf=expand_scores(pd.DataFrame([json.loads(x) for x in wpath.read_text(encoding='utf-8').splitlines() if x.strip()]))
        wdf.to_csv(out/'lasr_weight_sensitivity_raw.csv',index=False)
        ws=summarize(wdf,'weight_tag'); ws.to_csv(out/'lasr_weight_sensitivity_summary.csv',index=False)
    else: wdf=ws=None

    # publication-facing compact table
    cols=['condition','n_tasks','mean_overall_score','ci95_low_overall_score','ci95_high_overall_score']
    extra=[c for c in ['mean_operation_precision','mean_operation_recall','mean_operation_f1','mean_workflow_order','mean_hallucinated_operation_rate'] if c in summ]
    summ[cols+extra].to_csv(out/'table_lasr_ablation.csv',index=False)

    if plt is not None:
        order=['retrieval_only','single_scale','pooled_context','full_lasr']
        plot=summ.set_index('condition').reindex([x for x in order if x in set(summ.condition)]).dropna(how='all')
        if len(plot):
            fig,ax=plt.subplots(figsize=(7.2,4.2)); y=plot['mean_overall_score']; lo=y-plot['ci95_low_overall_score']; hi=plot['ci95_high_overall_score']-y
            ax.errorbar(range(len(plot)),y,yerr=[lo,hi],fmt='o',capsize=4)
            ax.set_xticks(range(len(plot))); ax.set_xticklabels(plot.index,rotation=20,ha='right');ax.set_ylabel('Mean task score');ax.set_title('LASR ablation (95% task-level bootstrap CI)');fig.tight_layout();fig.savefig(out/'figure_lasr_ablation.png',dpi=300);plt.close(fig)
        if ws is not None and len(ws):
            fig,ax=plt.subplots(figsize=(8,4.5)); ws2=ws.sort_values('mean_overall_score',ascending=False); ax.errorbar(range(len(ws2)),ws2.mean_overall_score,yerr=[ws2.mean_overall_score-ws2.ci95_low_overall_score,ws2.ci95_high_overall_score-ws2.mean_overall_score],fmt='o',capsize=3);ax.set_xticks(range(len(ws2)));ax.set_xticklabels(ws2.weight_tag,rotation=60,ha='right');ax.set_ylabel('Mean task score');ax.set_title('LASR weight sensitivity');fig.tight_layout();fig.savefig(out/'figure_lasr_weight_sensitivity.png',dpi=300);plt.close(fig)
    print(out)

if __name__=='__main__': main()
