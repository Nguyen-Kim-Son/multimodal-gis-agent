$ErrorActionPreference = "Stop"
python scripts\revision\run_weight_sensitivity.py `
  --config configs\revision\lasr_revision.yaml `
  --smoke-test `
  --smoke-tasks 2
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python scripts\revision\audit_weight_sensitivity.py `
  --run-dir outputs\revision\lasr_weight_sensitivity_v1_smoke `
  --strict
exit $LASTEXITCODE
