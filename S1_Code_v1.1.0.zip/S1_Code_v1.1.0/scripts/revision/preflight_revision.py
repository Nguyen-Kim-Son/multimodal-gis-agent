from __future__ import annotations

import importlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

# Directly executed scripts have scripts/revision on sys.path, not the
# repository root. Insert ROOT before importing project-local packages.
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

print(f"[PYTHON] {sys.executable}")
print(f"[VERSION] {sys.version.split()[0]}")
print(f"[ROOT] {ROOT}")
print(f"[IMPORT ROOT] {sys.path[0]}")

required = ["numpy", "pandas", "scipy", "matplotlib", "yaml", "pydantic", "requests"]
failed = []

for name in required:
    try:
        mod = importlib.import_module(name)
        version = getattr(mod, "__version__", "unknown")
        print(f"[OK] {name}: {version}")
    except Exception as exc:
        failed.append((name, repr(exc)))
        print(f"[FAIL] {name}: {exc}")

for pkg in ["revision", "lasr", "tasks", "models", "evaluation"]:
    try:
        mod = importlib.import_module(pkg)
        location = getattr(mod, "__file__", None)
        print(f"[OK] local package: {pkg} -> {location}")
    except Exception as exc:
        failed.append((pkg, repr(exc)))
        print(f"[FAIL] local package {pkg}: {exc}")

if failed:
    print("\n[FAILED] Revision environment is not ready.")
    for name, exc in failed:
        print(f" - {name}: {exc}")
    raise SystemExit(1)

print("\n[READY] Revision environment and local imports are valid.")
