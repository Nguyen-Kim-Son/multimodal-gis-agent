$ErrorActionPreference = "Stop"

python scripts\revision\run_lasr_ablation.py `
  --config configs\revision\lasr_revision.yaml `
  --smoke-test `
  --smoke-tasks 2

if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

python scripts\revision\audit_experimental_control.py `
  --run-dir outputs\revision\lasr_revision_v1_smoke `
  --strict

exit $LASTEXITCODE
