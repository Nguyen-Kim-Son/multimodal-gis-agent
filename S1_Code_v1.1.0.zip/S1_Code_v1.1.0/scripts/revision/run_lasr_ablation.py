from __future__ import annotations

import argparse
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from revision.lasr_runner import run_revision_experiment


def main() -> None:
    p = argparse.ArgumentParser(
        description="Run LASR ablation revision experiment."
    )
    p.add_argument(
        "--config",
        default="configs/revision/lasr_revision.yaml",
    )
    p.add_argument(
        "--smoke-test",
        action="store_true",
        help=(
            "Run a small validation job using all configured LASR variants, "
            "one repeat, and a small deterministic subset of tasks. Results "
            "are written to a separate *_smoke run directory."
        ),
    )
    p.add_argument(
        "--smoke-tasks",
        type=int,
        default=None,
        help="Override the number of tasks used by --smoke-test.",
    )
    a = p.parse_args()

    config_path = Path(a.config)
    if not config_path.is_absolute():
        config_path = ROOT / config_path

    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    result = run_revision_experiment(
        cfg,
        project_root=ROOT,
        smoke_test=a.smoke_test,
        smoke_tasks=a.smoke_tasks,
    )
    print(f"[RUN ROOT] {result}")


if __name__ == "__main__":
    main()
