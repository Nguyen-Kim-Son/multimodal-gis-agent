from __future__ import annotations
import argparse,json,sys
from pathlib import Path
import pandas as pd
def gate(df):
    reasons=[]
    if len(df)!=22: reasons.append(f"expected exactly 22 smoke calls, got {len(df)}")
    if df.weight_tag.nunique()!=11: reasons.append(f"expected 11 weight configurations, got {df.weight_tag.nunique()}")
    if df.task_id.nunique()!=2: reasons.append(f"expected 2 smoke tasks, got {df.task_id.nunique()}")
    if df[["weight_tag","task_id","repeat"]].duplicated().any(): reasons.append("duplicate weight/task/repeat cells")
    counts=df.groupby("weight_tag").task_id.nunique()
    if len(counts)!=11 or not (counts==2).all(): reasons.append("each weight must contain both smoke tasks")
    sets=[frozenset(g.task_id) for _,g in df.groupby("weight_tag")]
    if sets and len(set(sets))!=1: reasons.append("task IDs differ across weights")
    if df.repeat.nunique()!=1: reasons.append("smoke must use one repeat")
    if df.error.fillna("").astype(str).str.strip().ne("").any(): reasons.append("API/evaluation errors present")
    if df.truncated.fillna(False).astype(bool).any(): reasons.append("truncation present")
    if df.finish_reason.fillna("").astype(str).str.lower().isin(["length","max_tokens"]).any(): reasons.append("length-limited finish_reason present")
    for c in ["request_max_tokens","request_temperature","request_timeout"]:
        if df[c].nunique(dropna=False)!=1: reasons.append(f"non-identical generation control: {c}")
    ceiling=float(df.request_max_tokens.iloc[0])
    if (df.completion_tokens.fillna(0).astype(float)/ceiling>=.95).any(): reasons.append("one or more calls used >=95% output ceiling")
    # Ensure weights sum to 1 within numerical tolerance.
    sums=df.weight_local+df.weight_regional+df.weight_global
    if ((sums-1).abs()>1e-6).any(): reasons.append("weight triplet does not sum to 1")
    return not reasons,reasons
def main():
    p=argparse.ArgumentParser();p.add_argument("--run-dir",required=True);p.add_argument("--strict",action="store_true");a=p.parse_args()
    d=Path(a.run_dir); rows=[json.loads(x) for x in (d/"weight_sensitivity_results.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]
    df=pd.DataFrame(rows); ok,reasons=gate(df); audit=d/"audit";audit.mkdir(exist_ok=True)
    df.to_csv(audit/"weight_sensitivity_calls.csv",index=False)
    summary=df.groupby(["weight_tag","weight_local","weight_regional","weight_global"],as_index=False).agg(
        n_calls=("task_id","size"),mean_score=("overall_score","mean"),mean_prompt_tokens=("prompt_tokens","mean"),
        mean_completion_tokens=("completion_tokens","mean"),max_completion_tokens=("completion_tokens","max"),
        truncation_rate=("truncated","mean")).copy()
    summary.to_csv(audit/"weight_sensitivity_summary.csv",index=False)
    (audit/"production_gate.txt").write_text(("PASS\n" if ok else "FAIL\n"+"\n".join(reasons)+"\n"),encoding="utf-8")
    print(summary.to_string(index=False))
    print("\n[GATE: PASS] 22-call sensitivity smoke passed; 385-call production is permitted." if ok else "\n[GATE: FAIL] Do not start 385-call production.")
    for r in reasons: print(" -",r)
    if a.strict and not ok: sys.exit(2)
if __name__=="__main__":main()
