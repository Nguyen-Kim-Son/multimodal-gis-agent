from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd


def evaluate_gate(df: pd.DataFrame) -> tuple[bool, list[str]]:
    reasons: list[str] = []

    expected_conditions = {
        "full_lasr", "single_scale", "pooled_context", "retrieval_only"
    }
    conditions = set(df["condition"].dropna().astype(str)) if "condition" in df else set()
    if conditions != expected_conditions:
        reasons.append(
            f"expected exactly four conditions {sorted(expected_conditions)}, got {sorted(conditions)}"
        )

    # Smoke protocol is exactly 2 tasks x 4 conditions x 1 repeat = 8 calls.
    if len(df) != 8:
        reasons.append(f"smoke run must contain exactly 8 calls, got {len(df)}")

    if "task_id" in df:
        task_counts = df.groupby("condition")["task_id"].nunique()
        if len(task_counts) != 4 or not (task_counts == 2).all():
            reasons.append("each condition must contain exactly the same two smoke tasks")
        task_sets = [frozenset(g["task_id"]) for _, g in df.groupby("condition")]
        if task_sets and len(set(task_sets)) != 1:
            reasons.append("smoke task IDs differ across conditions")

    if "repeat" in df and df["repeat"].nunique() != 1:
        reasons.append("smoke run must use exactly one repeat")

    if "error" in df:
        errors = df["error"].fillna("").astype(str).str.strip()
        if (errors != "").any():
            reasons.append(f"API/evaluation errors present in {(errors != '').sum()} call(s)")

    if "truncated" not in df:
        reasons.append("truncation audit field is missing")
    elif df["truncated"].fillna(False).astype(bool).any():
        reasons.append(f"truncation present in {int(df['truncated'].fillna(False).astype(bool).sum())} call(s)")

    for col in ("request_max_tokens", "request_temperature", "request_timeout"):
        if col not in df:
            reasons.append(f"generation-control field missing: {col}")
        elif df[col].nunique(dropna=False) != 1:
            reasons.append(f"generation control is not identical across calls: {col}")

    if "completion_tokens" in df and "request_max_tokens" in df:
        ceiling = float(df["request_max_tokens"].dropna().iloc[0]) if df["request_max_tokens"].notna().any() else None
        if ceiling:
            ratio = df["completion_tokens"].fillna(0).astype(float) / ceiling
            # A response using >=95% of the ceiling is treated as near-ceiling,
            # even if the provider reports finish_reason=stop.
            near = ratio >= 0.95
            if near.any():
                reasons.append(
                    f"{int(near.sum())} call(s) used >=95% of the output ceiling"
                )

    if "finish_reason" in df:
        bad = df["finish_reason"].fillna("").astype(str).str.lower().isin(
            {"length", "max_tokens"}
        )
        if bad.any():
            reasons.append(f"length-limited finish_reason in {int(bad.sum())} call(s)")

    return (len(reasons) == 0), reasons


def main() -> None:
    p = argparse.ArgumentParser(
        description="Audit experimental-control balance and production readiness."
    )
    p.add_argument("--run-dir", required=True)
    p.add_argument("--output", default=None)
    p.add_argument(
        "--strict",
        action="store_true",
        help="Exit with status 2 when the production gate fails.",
    )
    a = p.parse_args()

    run_dir = Path(a.run_dir)
    src = run_dir / "lasr_revision_results.jsonl"
    if not src.exists():
        raise FileNotFoundError(src)

    rows = [
        json.loads(line)
        for line in src.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    df = pd.DataFrame(rows)

    cols = [
        "condition", "task_id", "repeat", "overall_score", "passed",
        "prompt_tokens", "completion_tokens", "total_tokens",
        "finish_reason", "truncated", "request_max_tokens",
        "request_temperature", "request_timeout",
        "treatment_policy_chars", "controlled_suffix_chars",
        "final_system_chars", "response_chars", "response_words",
        "latency_seconds", "error",
    ]
    detail = df[[c for c in cols if c in df.columns]].copy()

    agg_spec = {}
    candidates = {
        "n_calls": ("task_id", "count"),
        "mean_score": ("overall_score", "mean"),
        "mean_prompt_tokens": ("prompt_tokens", "mean"),
        "mean_completion_tokens": ("completion_tokens", "mean"),
        "max_completion_tokens": ("completion_tokens", "max"),
        "mean_total_tokens": ("total_tokens", "mean"),
        "mean_response_words": ("response_words", "mean"),
        "max_response_words": ("response_words", "max"),
        "mean_latency_seconds": ("latency_seconds", "mean"),
        "truncation_rate": ("truncated", "mean"),
    }
    for name, spec in candidates.items():
        if spec[0] in df.columns:
            agg_spec[name] = spec
    summary = df.groupby("condition", as_index=False).agg(**agg_spec)

    passed, reasons = evaluate_gate(df)
    out_dir = Path(a.output) if a.output else run_dir / "audit"
    out_dir.mkdir(parents=True, exist_ok=True)
    detail.to_csv(out_dir / "experimental_control_calls.csv", index=False)
    summary.to_csv(out_dir / "experimental_control_summary.csv", index=False)

    gate_text = ["PASS" if passed else "FAIL"]
    gate_text.extend(reasons)
    (out_dir / "production_gate.txt").write_text(
        "\n".join(gate_text) + "\n", encoding="utf-8"
    )

    print(summary.to_string(index=False))
    if passed:
        print("\n[GATE: PASS] Smoke protocol passed the automatic production-readiness checks.")
    else:
        print("\n[GATE: FAIL] Do not start the production run.")
        for reason in reasons:
            print(f" - {reason}")
    print(f"[AUDIT] output={out_dir}")

    if a.strict and not passed:
        sys.exit(2)


if __name__ == "__main__":
    main()
