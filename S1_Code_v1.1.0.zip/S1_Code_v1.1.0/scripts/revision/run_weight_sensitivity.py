from __future__ import annotations
import argparse, sys
from pathlib import Path
import yaml
ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from revision.weight_runner import run_weight_sensitivity
p=argparse.ArgumentParser(description="Run prespecified LASR weight-sensitivity robustness analysis.")
p.add_argument("--config",required=True);p.add_argument("--smoke-test",action="store_true");p.add_argument("--smoke-tasks",type=int,default=2)
a=p.parse_args()
cfg=yaml.safe_load(Path(a.config).read_text(encoding="utf-8"))
run_weight_sensitivity(cfg,project_root=ROOT,smoke_test=a.smoke_test,smoke_tasks=a.smoke_tasks)
