from __future__ import annotations
import argparse, json, math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
import matplotlib.pyplot as plt

CONDITIONS = ["full_lasr","single_scale","pooled_context","retrieval_only"]
LABELS = {
    "full_lasr":"Full LASR",
    "single_scale":"Single scale",
    "pooled_context":"Pooled context",
    "retrieval_only":"Retrieval only",
}
PRIMARY = ["single_scale","pooled_context","retrieval_only"]

def bootstrap_mean_ci(x, n=10000, seed=20260915):
    x=np.asarray(x,float); rng=np.random.default_rng(seed)
    means=np.empty(n)
    for i in range(n):
        means[i]=rng.choice(x,size=len(x),replace=True).mean()
    return float(x.mean()), float(np.quantile(means,.025)), float(np.quantile(means,.975))

def paired_bootstrap_ci(d, n=10000, seed=20260915):
    return bootstrap_mean_ci(np.asarray(d,float),n,seed)

def rank_biserial(d):
    d=np.asarray(d,float); d=d[np.isfinite(d) & (d!=0)]
    if len(d)==0: return 0.0
    ranks=pd.Series(np.abs(d)).rank(method="average").to_numpy()
    pos=ranks[d>0].sum(); neg=ranks[d<0].sum()
    den=pos+neg
    return float((pos-neg)/den) if den else 0.0

def holm_adjust(pvals):
    p=np.asarray(pvals,float); m=len(p); order=np.argsort(p)
    adj=np.empty(m); running=0.0
    for j,idx in enumerate(order):
        val=(m-j)*p[idx]
        running=max(running,val)
        adj[idx]=min(1.0,running)
    return adj

def load_jsonl(path):
    return pd.DataFrame([json.loads(x) for x in Path(path).read_text(encoding="utf-8").splitlines() if x.strip()])

def integrity(df):
    problems=[]
    if len(df)!=420: problems.append(f"expected 420 rows, got {len(df)}")
    if set(df.condition)!=set(CONDITIONS): problems.append("condition set mismatch")
    if df[["condition","task_id","repeat"]].duplicated().any(): problems.append("duplicate condition/task/repeat rows")
    counts=df.groupby("condition").size()
    if not all(counts.get(c,0)==105 for c in CONDITIONS): problems.append(f"condition counts={counts.to_dict()}")
    tc=df.groupby(["condition","task_id"]).size()
    if not (tc==3).all(): problems.append("not every condition/task has exactly 3 repeats")
    if df.task_id.nunique()!=35: problems.append(f"expected 35 tasks, got {df.task_id.nunique()}")
    if "truncated" in df and df.truncated.fillna(False).astype(bool).any(): problems.append("truncated calls present")
    if "error" in df and df.error.fillna("").astype(str).str.strip().ne("").any(): problems.append("errors present")
    return problems

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--results",required=True)
    ap.add_argument("--output",required=True)
    ap.add_argument("--bootstrap",type=int,default=10000)
    ap.add_argument("--seed",type=int,default=20260915)
    a=ap.parse_args()
    out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
    df=load_jsonl(a.results)
    probs=integrity(df)
    (out/"integrity_check.txt").write_text(("PASS\n" if not probs else "FAIL\n"+"\n".join(probs)+"\n"),encoding="utf-8")
    if probs: raise SystemExit("Integrity check failed: "+"; ".join(probs))

    # Raw descriptive statistics: responses are repeated observations, not inferential units.
    raw=df.groupby("condition").agg(
        n_responses=("overall_score","size"),
        mean_score=("overall_score","mean"),
        sd_score=("overall_score","std"),
        pass_rate=("passed","mean"),
        mean_prompt_tokens=("prompt_tokens","mean"),
        mean_completion_tokens=("completion_tokens","mean"),
        mean_latency_seconds=("latency_seconds","mean"),
    ).reset_index()
    raw["condition_label"]=raw.condition.map(LABELS)
    raw.to_csv(out/"raw_response_descriptives.csv",index=False)

    # Inferential unit = unique task; average the three repeats within task-condition.
    task=df.groupby(["task_id","condition"],as_index=False).agg(
        mean_score=("overall_score","mean"),
        pass_rate=("passed","mean"),
    )
    task.to_csv(out/"task_level_means.csv",index=False)

    # Task-level condition summaries and bootstrap CIs.
    rows=[]
    for c in CONDITIONS:
        x=task.loc[task.condition==c,"mean_score"].to_numpy()
        mean,lo,hi=bootstrap_mean_ci(x,a.bootstrap,a.seed)
        rows.append({"condition":c,"condition_label":LABELS[c],"n_tasks":len(x),
                     "mean_task_score":mean,"bootstrap_ci_low":lo,"bootstrap_ci_high":hi})
    summ=pd.DataFrame(rows)
    summ.to_csv(out/"task_level_summary.csv",index=False)

    # Primary paired Full-LASR contrasts.
    wide=task.pivot(index="task_id",columns="condition",values="mean_score").sort_index()
    pairs=[]
    for i,c in enumerate(PRIMARY):
        d=(wide["full_lasr"]-wide[c]).to_numpy()
        mean,lo,hi=paired_bootstrap_ci(d,a.bootstrap,a.seed+i+1)
        try:
            stat,p=wilcoxon(d,zero_method="wilcox",alternative="two-sided",method="auto")
        except ValueError:
            stat,p=0.0,1.0
        pairs.append({
            "contrast":f"Full LASR - {LABELS[c]}",
            "comparator":c,
            "n_tasks":len(d),
            "mean_difference":mean,
            "bootstrap_ci_low":lo,
            "bootstrap_ci_high":hi,
            "wilcoxon_W":float(stat),
            "p_raw":float(p),
            "rank_biserial_effect":rank_biserial(d),
            "full_wins":int((d>0).sum()),
            "ties":int((d==0).sum()),
            "full_losses":int((d<0).sum()),
        })
    pair=pd.DataFrame(pairs)
    pair["p_holm"]=holm_adjust(pair.p_raw.to_numpy())
    pair["significant_holm_0_05"]=pair.p_holm<.05
    pair.to_csv(out/"primary_paired_contrasts.csv",index=False)

    # Component-level descriptive analysis, if evaluator scores are present.
    score_keys=sorted({k for x in df.get("scores",[]) if isinstance(x,dict) for k in x.keys()})
    comp_rows=[]
    for _,r in df.iterrows():
        sc=r.get("scores",{})
        if not isinstance(sc,dict): continue
        for k,v in sc.items():
            if isinstance(v,(int,float)) and not isinstance(v,bool):
                comp_rows.append({"condition":r.condition,"task_id":r.task_id,"repeat":r.repeat,
                                  "component":k,"value":float(v)})
    if comp_rows:
        comp=pd.DataFrame(comp_rows)
        comp_task=comp.groupby(["condition","task_id","component"],as_index=False).value.mean()
        comp_sum=comp_task.groupby(["condition","component"]).agg(
            n_tasks=("value","size"),mean=("value","mean"),sd=("value","std")
        ).reset_index()
        comp_task.to_csv(out/"component_task_level.csv",index=False)
        comp_sum.to_csv(out/"component_descriptives.csv",index=False)

    # Publication-ready table.
    pub=summ[["condition_label","n_tasks","mean_task_score","bootstrap_ci_low","bootstrap_ci_high"]].copy()
    pub["Mean score (95% bootstrap CI)"]=pub.apply(
        lambda r:f'{r.mean_task_score:.3f} ({r.bootstrap_ci_low:.3f}, {r.bootstrap_ci_high:.3f})',axis=1)
    pub=pub[["condition_label","n_tasks","Mean score (95% bootstrap CI)"]]
    pub.to_csv(out/"publication_table_ablation.csv",index=False)

    # Figure 1: task-level means with bootstrap CI.
    order=summ.sort_values("mean_task_score",ascending=False)
    y=np.arange(len(order))
    means=order.mean_task_score.to_numpy()
    lo=order.bootstrap_ci_low.to_numpy(); hi=order.bootstrap_ci_high.to_numpy()
    fig,ax=plt.subplots(figsize=(7.2,4.2))
    ax.errorbar(means,y,xerr=np.vstack([means-lo,hi-means]),fmt="o",capsize=4)
    ax.set_yticks(y,order.condition_label)
    ax.set_xlabel("Mean task-level overall score (95% bootstrap CI)")
    ax.set_title("LASR ablation: 35 unique tasks, three repeats per condition")
    ax.grid(axis="x",alpha=.25)
    fig.tight_layout()
    fig.savefig(out/"figure_ablation_task_level.png",dpi=300,bbox_inches="tight")
    plt.close(fig)

    # Figure 2: paired differences, Full LASR minus comparator.
    fig,ax=plt.subplots(figsize=(7.2,4.2))
    py=np.arange(len(pair))
    pm=pair.mean_difference.to_numpy()
    plo=pair.bootstrap_ci_low.to_numpy(); phi=pair.bootstrap_ci_high.to_numpy()
    ax.errorbar(pm,py,xerr=np.vstack([pm-plo,phi-pm]),fmt="o",capsize=4)
    ax.axvline(0,linewidth=1)
    ax.set_yticks(py,pair.contrast)
    ax.set_xlabel("Paired mean difference in task-level score (95% bootstrap CI)")
    ax.set_title("Primary paired contrasts")
    ax.grid(axis="x",alpha=.25)
    fig.tight_layout()
    fig.savefig(out/"figure_primary_paired_contrasts.png",dpi=300,bbox_inches="tight")
    plt.close(fig)

    # Machine-readable and manuscript-ready text summary.
    best=summ.sort_values("mean_task_score",ascending=False).iloc[0]
    lines=[
        "LASR ABLATION STATISTICAL REPORT",
        "Inferential unit: unique task (n=35). Three model repeats were averaged within each task-condition.",
        f"Bootstrap: {a.bootstrap:,} resamples of tasks; seed={a.seed}.",
        "Primary tests: two-sided paired Wilcoxon signed-rank tests comparing Full LASR with each comparator.",
        "Multiplicity: Holm correction across the three primary contrasts.",
        "",
        f"Highest descriptive task-level mean: {best.condition_label} = {best.mean_task_score:.4f}.",
        "",
        "Primary contrasts:"
    ]
    for _,r in pair.iterrows():
        lines.append(
            f"- {r.contrast}: mean difference={r.mean_difference:.4f}, "
            f"95% bootstrap CI [{r.bootstrap_ci_low:.4f}, {r.bootstrap_ci_high:.4f}], "
            f"W={r.wilcoxon_W:.1f}, raw p={r.p_raw:.6g}, Holm p={r.p_holm:.6g}, "
            f"rank-biserial={r.rank_biserial_effect:.3f}, "
            f"wins/ties/losses={int(r.full_wins)}/{int(r.ties)}/{int(r.full_losses)}."
        )
    lines += [
        "",
        "Interpretation rule: do not treat the 420 repeated responses as independent inferential units.",
        "A non-significant contrast is evidence of no detected difference under this benchmark, not proof of equivalence.",
        "Weight sensitivity, if run later, is a robustness analysis and must not retroactively redefine this primary ablation."
    ]
    (out/"statistical_summary.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print("\n".join(lines))
    print(f"\n[REPORT] {out}")

if __name__=="__main__":
    main()
