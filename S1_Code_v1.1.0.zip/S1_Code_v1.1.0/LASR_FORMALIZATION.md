# LASR formalization and implementation boundary

For query q, layer l and scale s:

    c_s(q,l) = [C_sem, C_sp,s, C_temp, C_res,s, C_prov, C_op]

    C_sp,s = |A_q ∩ A_l^(s)| / |A_q|
    C_temp = |T_q ∩ T_l| / |T_q|
    C_res,s = exp(-|log(rho_l / rho_q^(s))|)
    H(q,l) = I(C_sp>0) I(C_temp>0) I(C_op>0) I(C_access=1)

The scale scores are combined by the prespecified weights, and the gated score is H(q,l) R_s.

The code in `lasr/strategy.py` realizes the scale partition as a prompt policy. The equations define the intended compatibility semantics; they are not a separately executed numeric predictor in the released ablation. Retain this distinction in the manuscript.
