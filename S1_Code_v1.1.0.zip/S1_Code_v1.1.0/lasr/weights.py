from __future__ import annotations

from .strategy import LASRWeights


def default_weight_grid() -> list[LASRWeights]:
    """Predeclared sensitivity grid around and beyond the manuscript weights.

    This is deliberately finite rather than selected after observing outcomes.
    """
    triples = [
        (0.40, 0.40, 0.20),
        (0.50, 0.30, 0.20),
        (0.30, 0.50, 0.20),
        (0.40, 0.30, 0.30),
        (0.30, 0.40, 0.30),
        (0.50, 0.40, 0.10),
        (0.40, 0.50, 0.10),
        (0.60, 0.20, 0.20),
        (0.20, 0.60, 0.20),
        (0.20, 0.20, 0.60),
        (1 / 3, 1 / 3, 1 / 3),
    ]
    return [LASRWeights(*t) for t in triples]
