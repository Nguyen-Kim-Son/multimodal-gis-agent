from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from tasks.schema import Task


class LASRVariant(str, Enum):
    FULL = "full_lasr"
    SINGLE = "single_scale"
    POOLED = "pooled_context"
    RETRIEVAL_ONLY = "retrieval_only"


@dataclass(frozen=True, slots=True)
class LASRWeights:
    local: float = 0.4
    regional: float = 0.4
    global_: float = 0.2

    def __post_init__(self) -> None:
        values = (self.local, self.regional, self.global_)
        if any(v < 0 or v > 1 for v in values):
            raise ValueError("LASR weights must lie in [0, 1].")
        if abs(sum(values) - 1.0) > 1e-9:
            raise ValueError("LASR weights must sum to 1.")

    @property
    def tag(self) -> str:
        return f"L{self.local:.2f}_R{self.regional:.2f}_G{self.global_:.2f}"


def _dataset_block(task: Task) -> str:
    if not task.datasets:
        return "No declared candidate datasets."
    rows = []
    for ds in task.datasets:
        fields = [
            f"id={ds.id}",
            f"name={ds.name}",
            f"provider={ds.provider.value}",
            f"asset={ds.asset}",
        ]
        if ds.resolution is not None:
            fields.append(f"resolution={ds.resolution}")
        if ds.temporal_resolution:
            fields.append(f"temporal_resolution={ds.temporal_resolution}")
        if ds.bands:
            fields.append("bands=" + ",".join(ds.bands))
        rows.append("- " + "; ".join(fields))
    return "\n".join(rows)


COMMON_RESPONSE_CONTRACT = """
OUTPUT CONTRACT (identical for every condition)
Return only these four sections:
1. DATASETS: selected declared dataset IDs; one sentence per dataset, maximum 30 words each.
2. WORKFLOW: 3-8 numbered essential GIS operations; maximum 35 words per operation.
3. ASSUMPTIONS: 0-3 bullets; maximum 25 words per bullet.
4. VALIDATION: 1-3 bullets; maximum 25 words per bullet.

Hard brevity rules: target <=700 words total and never exceed 8 WORKFLOW
operations. Do not include introductions, conclusions, alternatives, code, pseudo-code, or equations.
Do not reveal hidden chain-of-thought or write a reasoning transcript.
Do not invent executed numeric results. Do not add optional operations unless
they are necessary for the requested workflow.
""".strip()


def _common(task: Task) -> str:
    return f"""
REVISION EXPERIMENT -- CONTROLLED REASONING CONDITION
Task ID: {task.id}

DECLARED CANDIDATE DATASETS
{_dataset_block(task)}

Use only the user request and the declared candidate-dataset metadata as
evidence. Apply the assigned policy internally, then return the same output
format for every condition.

{COMMON_RESPONSE_CONTRACT}
""".strip()


def _policy(variant: LASRVariant, weights: LASRWeights) -> str:
    if variant is LASRVariant.FULL:
        return (
            "POLICY: FULL LASR. Internally assess evidence at LOCAL "
            "(feature/neighbourhood fit), REGIONAL (study-region compatibility), "
            "and GLOBAL (extent/provenance/temporal consistency) scales. Resolve "
            f"compatible evidence with fixed weights L={weights.local:.2f}, "
            f"R={weights.regional:.2f}, G={weights.global_:.2f}. An explicit "
            "incompatibility cannot be overridden by a high weighted score."
        )
    if variant is LASRVariant.SINGLE:
        return (
            "POLICY: SINGLE SCALE. Internally assess evidence only at the immediate "
            "feature/neighbourhood scale using direct spatial fit, local resolution, "
            "and operation compatibility. Do not create regional/global channels or "
            "scale weights. Use the same declared evidence and output contract."
        )
    if variant is LASRVariant.POOLED:
        return (
            "POLICY: POOLED CONTEXT. Internally assess all declared spatial, temporal, "
            "provenance, resolution, and operation evidence jointly as one evidence "
            "pool. Do not partition evidence by scale and do not apply scale-specific "
            "weights. Use the same declared evidence and output contract."
        )
    return (
        "POLICY: RETRIEVAL ONLY. Select declared datasets using semantic relevance "
        "and basic availability/metadata compatibility, then synthesize the minimal "
        "workflow directly. Do not perform explicit scale-partitioned reasoning or "
        "scale weighting. Use the same declared evidence and output contract."
    )


def build_reasoning_prompt(
    task: Task,
    variant: LASRVariant | str,
    *,
    weights: LASRWeights | None = None,
) -> str:
    """Build the controlled LASR treatment prompt.

    All conditions share the evidence block and final-answer contract. The only
    intended treatment difference is the internal evidence-integration policy.
    """
    variant = LASRVariant(variant)
    weights = weights or LASRWeights()
    return _common(task) + "\n\n" + _policy(variant, weights)


def treatment_policy_text(
    variant: LASRVariant | str,
    *,
    weights: LASRWeights | None = None,
) -> str:
    """Return only the treatment-specific policy text for audit tables."""
    variant = LASRVariant(variant)
    return _policy(variant, weights or LASRWeights())
