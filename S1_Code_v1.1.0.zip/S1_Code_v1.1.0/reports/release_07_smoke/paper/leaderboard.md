# MMGIS-Bench Leaderboard

| Rank | Model | Mean score | CI95 low | CI95 high | Pass rate | Latency (s) | Cost (USD) |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | mock | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.0000 |
