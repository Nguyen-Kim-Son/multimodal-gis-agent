from __future__ import annotations

import hashlib
import json
import math
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from benchmark import BenchmarkRunner
from lasr import LASRVariant, LASRWeights, build_reasoning_prompt
from lasr.strategy import treatment_policy_text
from models import create_model
from tasks import load_directory


def _load_done(path: Path) -> set[tuple[str, str, int, str]]:
    if not path.exists():
        return set()
    done = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            r = json.loads(line)
            done.add(
                (
                    str(r["condition"]),
                    str(r["weight_tag"]),
                    int(r["repeat"]),
                    str(r["task_id"]),
                )
            )
        except Exception:
            continue
    return done


def _fmt_duration(seconds: float | None) -> str:
    if seconds is None or not math.isfinite(seconds):
        return "--"
    seconds = max(0, int(round(seconds)))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def _select_smoke_tasks(tasks: list[Any], n: int) -> list[Any]:
    """Deterministically choose a small spread of tasks for a smoke run."""
    n = max(1, min(int(n), len(tasks)))
    if n >= len(tasks):
        return list(tasks)
    if n == 1:
        return [tasks[0]]
    # Spread picks across the sorted task list rather than taking only the first n.
    idx = [round(i * (len(tasks) - 1) / (n - 1)) for i in range(n)]
    seen: set[int] = set()
    out = []
    for i in idx:
        if i not in seen:
            out.append(tasks[i])
            seen.add(i)
    return out


def run_revision_experiment(
    config: dict[str, Any],
    *,
    project_root: str | Path = ".",
    smoke_test: bool = False,
    smoke_tasks: int | None = None,
) -> Path:
    root = Path(project_root).resolve()
    exp = config["experiment"]
    control = config.get("experimental_control", {})
    controlled_max_tokens = int(control.get("max_tokens", 1600))
    controlled_temperature = float(control.get("temperature", 0.0))
    controlled_timeout = int(control.get("timeout", 300))
    tasks = load_directory(root / str(exp["tasks"]))

    smoke_cfg = config.get("smoke_test", {})
    if smoke_test:
        requested = smoke_tasks if smoke_tasks is not None else int(smoke_cfg.get("n_tasks", 2))
        tasks = _select_smoke_tasks(tasks, requested)

    model_key = str(exp["model_key"])
    model_cfg = config["models"][model_key]
    model = create_model(model_cfg)

    # Attach retry logger if the selected adapter supports it.
    if hasattr(model, "set_retry_logger"):
        model.set_retry_logger(lambda msg: print(msg, flush=True))

    output_root = root / str(exp.get("output_root", "outputs/revision"))
    base_run_id = str(exp.get("run_id", "lasr_revision_v1"))
    run_id = f"{base_run_id}_smoke" if smoke_test else base_run_id
    run_root = output_root / run_id
    run_root.mkdir(parents=True, exist_ok=True)
    out = run_root / "lasr_revision_results.jsonl"
    done = _load_done(out) if bool(exp.get("resume", True)) else set()

    variants = [
        LASRVariant(v)
        for v in exp.get("variants", [v.value for v in LASRVariant])
    ]
    repeats = 1 if smoke_test else int(exp.get("repeats", 3))
    base_weights = LASRWeights(
        **config.get(
            "lasr",
            {},
        ).get(
            "weights",
            {"local": 0.4, "regional": 0.4, "global_": 0.2},
        )
    )

    planned_keys: list[tuple[LASRVariant, str, int, Any]] = []
    for variant in variants:
        weight_tag = base_weights.tag if variant is LASRVariant.FULL else "NA"
        for repeat in range(1, repeats + 1):
            for task in tasks:
                planned_keys.append((variant, weight_tag, repeat, task))

    n_total = len(planned_keys)
    n_already_done = sum(
        1
        for variant, weight_tag, repeat, task in planned_keys
        if (variant.value, weight_tag, repeat, task.id) in done
    )
    n_pending = n_total - n_already_done

    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "tasks": str(exp["tasks"]),
        "n_tasks": len(tasks),
        "model_key": model_key,
        "model": model_cfg.get("model"),
        "variants": [v.value for v in variants],
        "repeats": repeats,
        "base_weights": {
            "local": base_weights.local,
            "regional": base_weights.regional,
            "global": base_weights.global_,
        },
        "smoke_test": smoke_test,
        "smoke_task_ids": [t.id for t in tasks] if smoke_test else [],
        "n_planned_calls": n_total,
        "n_already_done_at_start": n_already_done,
        "experimental_control": {
            "max_tokens": controlled_max_tokens,
            "temperature": controlled_temperature,
            "timeout": controlled_timeout,
            "common_output_contract": True,
            "chain_of_thought_requested": False,
        },
        "design_note": (
            "Conditions differ only in reasoning-policy system prompt; task, "
            "candidate datasets, model, temperature and evaluator are held fixed."
        ),
    }
    (run_root / "manifest.json").write_text(
        json.dumps(manifest, indent=2),
        encoding="utf-8",
    )

    mode_name = "SMOKE" if smoke_test else "FULL"
    print(
        f"[LASR] mode={mode_name} model={model_cfg.get('model')} "
        f"tasks={len(tasks)} variants={len(variants)} repeats={repeats}",
        flush=True,
    )
    print(
        f"[LASR] planned={n_total} already_done={n_already_done} pending={n_pending}",
        flush=True,
    )
    print(f"[LASR] output={out}", flush=True)
    print(
        f"[CONTROL] max_tokens={controlled_max_tokens} "
        f"temperature={controlled_temperature} timeout={controlled_timeout}s",
        flush=True,
    )
    print(
        "[LASR] weights="
        f"local:{base_weights.local:.3f}, "
        f"regional:{base_weights.regional:.3f}, "
        f"global:{base_weights.global_:.3f}",
        flush=True,
    )
    if smoke_test:
        print(
            "[LASR] smoke_task_ids=" + ",".join(t.id for t in tasks),
            flush=True,
        )

    if n_pending == 0:
        print("[DONE] No pending calls; all planned results already exist.", flush=True)
        return run_root

    run_start = time.perf_counter()
    completed_this_run = 0
    failures_this_run = 0
    latencies: list[float] = []

    with out.open("a" if out.exists() else "w", encoding="utf-8") as stream:
        for variant, weight_tag, repeat, task in planned_keys:
            key = (variant.value, weight_tag, repeat, task.id)
            if key in done:
                continue

            absolute_index = n_already_done + completed_this_run + 1
            print(
                f"[RUN] {absolute_index}/{n_total} "
                f"condition={variant.value} repeat={repeat}/{repeats} "
                f"task={task.id} name={task.name}",
                flush=True,
            )

            t = task.model_copy(deep=True)
            treatment = treatment_policy_text(variant, weights=base_weights)
            suffix = build_reasoning_prompt(t, variant, weights=base_weights)
            original = t.input.system_prompt or ""
            t.input.system_prompt = (original + "\n\n" + suffix).strip()

            # Identical generation controls across every ablation condition.
            t.runtime.max_tokens = controlled_max_tokens
            t.runtime.temperature = controlled_temperature
            t.runtime.timeout = controlled_timeout

            prompt_audit = {
                "original_system_chars": len(original),
                "treatment_policy_chars": len(treatment),
                "controlled_suffix_chars": len(suffix),
                "final_system_chars": len(t.input.system_prompt or ""),
                "user_prompt_chars": len(t.input.prompt),
                "treatment_policy_sha256": hashlib.sha256(
                    treatment.encode("utf-8")
                ).hexdigest(),
                "final_system_sha256": hashlib.sha256(
                    (t.input.system_prompt or "").encode("utf-8")
                ).hexdigest(),
            }

            runner = BenchmarkRunner(
                model,
                output_dir=(
                    run_root
                    / "raw"
                    / variant.value
                    / f"repeat_{repeat:02d}"
                    / t.id
                ),
                cache=bool(exp.get("cache", False)),
                resume=False,
            )

            call_start = time.perf_counter()
            rec = runner.run_task(t)
            wall_seconds = time.perf_counter() - call_start

            e = rec.evaluation or {}
            response = rec.response or {}
            prediction = rec.prediction or ""
            row = {
                "condition": variant.value,
                "weight_tag": weight_tag,
                "weight_local": (
                    base_weights.local
                    if variant is LASRVariant.FULL
                    else None
                ),
                "weight_regional": (
                    base_weights.regional
                    if variant is LASRVariant.FULL
                    else None
                ),
                "weight_global": (
                    base_weights.global_
                    if variant is LASRVariant.FULL
                    else None
                ),
                "repeat": repeat,
                "task_id": t.id,
                "task_name": t.name,
                "category": t.metadata.category.value,
                "difficulty": t.metadata.difficulty.value,
                "n_declared_datasets": len(t.datasets),
                "model_key": model_key,
                "model": rec.model,
                "provider": rec.provider,
                "overall_score": float(e.get("overall_score", 0.0)),
                "passed": bool(e.get("passed", False)),
                "scores": e.get("scores", {}),
                "latency_seconds": response.get("latency_seconds"),
                "prompt_tokens": response.get("prompt_tokens"),
                "completion_tokens": response.get("completion_tokens"),
                "total_tokens": response.get("total_tokens"),
                "cost_usd": response.get("cost_usd"),
                "finish_reason": response.get("finish_reason"),
                "truncated": bool(response.get("truncated", False)),
                "request_max_tokens": controlled_max_tokens,
                "request_temperature": controlled_temperature,
                "request_timeout": controlled_timeout,
                "response_chars": len(prediction),
                "response_words": len(prediction.split()),
                **prompt_audit,
                "error": rec.error,
            }

            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
            stream.flush()
            done.add(key)
            completed_this_run += 1
            latencies.append(wall_seconds)

            if rec.error:
                failures_this_run += 1
                status = "ERROR"
                metric = f"error={rec.error[:180]}"
            else:
                status = "OK"
                metric = (
                    f"score={row['overall_score']:.3f} "
                    f"passed={row['passed']} "
                    f"prompt_tok={row.get('prompt_tokens')} "
                    f"completion_tok={row.get('completion_tokens')} "
                    f"finish={row.get('finish_reason')} "
                    f"truncated={row.get('truncated')}"
                )

            elapsed = time.perf_counter() - run_start
            avg = sum(latencies) / len(latencies)
            remaining = n_pending - completed_this_run
            eta = avg * remaining

            print(
                f"[{status}] task={t.id} wall={wall_seconds:.1f}s {metric}",
                flush=True,
            )
            print(
                f"[PROGRESS] completed={completed_this_run}/{n_pending} "
                f"total={n_already_done + completed_this_run}/{n_total} "
                f"failures={failures_this_run} "
                f"avg={avg:.1f}s elapsed={_fmt_duration(elapsed)} "
                f"ETA={_fmt_duration(eta)}",
                flush=True,
            )

    total_elapsed = time.perf_counter() - run_start
    print(
        f"[DONE] completed_this_run={completed_this_run} "
        f"failures={failures_this_run} elapsed={_fmt_duration(total_elapsed)}",
        flush=True,
    )
    print(f"[DONE] results={out}", flush=True)
    return run_root
