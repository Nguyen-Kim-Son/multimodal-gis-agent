"""Revision experiments for LASR ablation and sensitivity analysis."""
