from __future__ import annotations
import hashlib, json, time
from pathlib import Path
from typing import Any
from benchmark import BenchmarkRunner
from lasr import LASRVariant, LASRWeights, build_reasoning_prompt
from models import create_model
from tasks import load_directory

PRESPECIFIED_GRID = [
    (0.40,0.40,0.20),(0.50,0.30,0.20),(0.30,0.50,0.20),
    (0.40,0.30,0.30),(0.30,0.40,0.30),(0.50,0.40,0.10),
    (0.40,0.50,0.10),(0.60,0.20,0.20),(0.20,0.60,0.20),
    (0.20,0.20,0.60),(0.3333,0.3333,0.3334),
]

def _select_smoke_tasks(tasks, n):
    if n >= len(tasks): return tasks
    if n == 1: return [tasks[0]]
    idx=[round(i*(len(tasks)-1)/(n-1)) for i in range(n)]
    return [tasks[i] for i in idx]

def _fmt(sec):
    sec=max(0,int(sec)); return f"{sec//3600:02d}:{(sec%3600)//60:02d}:{sec%60:02d}"

def run_weight_sensitivity(config: dict[str,Any], *, project_root=".", smoke_test=False, smoke_tasks=2)->Path:
    root=Path(project_root).resolve(); exp=config["experiment"]; ctl=config.get("experimental_control",{})
    max_tokens=int(ctl.get("max_tokens",1600)); temp=float(ctl.get("temperature",0.0)); timeout=int(ctl.get("timeout",300))
    tasks=load_directory(root/str(exp["tasks"]))
    if smoke_test: tasks=_select_smoke_tasks(tasks,smoke_tasks)
    model_key=str(exp["model_key"]); model=create_model(config["models"][model_key])
    base=str(config.get("weight_sensitivity",{}).get("run_id","lasr_weight_sensitivity_v1"))
    run_id=base+"_smoke" if smoke_test else base
    out_root=root/str(exp.get("output_root","outputs/revision"))/run_id; out_root.mkdir(parents=True,exist_ok=True)
    out=out_root/"weight_sensitivity_results.jsonl"
    custom=config.get("weight_sensitivity",{}).get("grid")
    raw_grid=custom if custom else PRESPECIFIED_GRID
    grid=[LASRWeights(float(x[0]),float(x[1]),float(x[2])) for x in raw_grid]
    if len(grid)!=11: raise ValueError(f"Prespecified sensitivity protocol requires exactly 11 weights, got {len(grid)}")
    repeats=1 if smoke_test else int(config.get("weight_sensitivity",{}).get("repeats",1))
    completed=set()
    if out.exists():
        for line in out.read_text(encoding="utf-8").splitlines():
            try:
                r=json.loads(line); completed.add((r["weight_tag"],int(r["repeat"]),r["task_id"]))
            except Exception: pass
    planned=len(grid)*len(tasks)*repeats; done0=len(completed); new_done=0; durations=[]
    manifest={"version":"0.8.7","analysis_role":"robustness_not_hyperparameter_selection",
              "smoke_test":smoke_test,"n_tasks":len(tasks),"n_weights":len(grid),"repeats":repeats,
              "planned_calls":planned,"weights":[list(x) for x in raw_grid],
              "experimental_control":{"max_tokens":max_tokens,"temperature":temp,"timeout":timeout}}
    (out_root/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    print(f"[WEIGHTS] mode={'SMOKE' if smoke_test else 'FULL'} tasks={len(tasks)} weights={len(grid)} repeats={repeats}")
    print(f"[WEIGHTS] planned={planned} already_completed={done0}")
    print(f"[CONTROL] max_tokens={max_tokens} temperature={temp} timeout={timeout}s")
    with out.open("a" if out.exists() else "w",encoding="utf-8") as stream:
        for wi,w in enumerate(grid):
            for repeat in range(1,repeats+1):
                for task in tasks:
                    key=(w.tag,repeat,task.id)
                    if key in completed: continue
                    start=time.time(); t=task.model_copy(deep=True); original=t.input.system_prompt or ""
                    suffix=build_reasoning_prompt(t,LASRVariant.FULL,weights=w)
                    t.input.system_prompt=(original+"\n\n"+suffix).strip()
                    t.runtime.max_tokens=max_tokens;t.runtime.temperature=temp;t.runtime.timeout=timeout
                    runner=BenchmarkRunner(model,output_dir=out_root/"raw_weights"/w.tag/f"repeat_{repeat:02d}"/t.id,cache=False,resume=False)
                    rec=runner.run_task(t); e=rec.evaluation or {}; rsp=rec.response or {}; elapsed=time.time()-start
                    row={"weight_tag":w.tag,"weight_local":w.local,"weight_regional":w.regional,"weight_global":w.global_,
                         "repeat":repeat,"task_id":t.id,"task_name":t.name,"category":t.metadata.category.value,
                         "difficulty":t.metadata.difficulty.value,"n_declared_datasets":len(t.datasets),"model_key":model_key,
                         "overall_score":float(e.get("overall_score",0.0)),"passed":bool(e.get("passed",False)),"scores":e.get("scores",{}),
                         "latency_seconds":rsp.get("latency_seconds"),"prompt_tokens":rsp.get("prompt_tokens"),
                         "completion_tokens":rsp.get("completion_tokens"),"total_tokens":rsp.get("total_tokens"),"cost_usd":rsp.get("cost_usd"),
                         "finish_reason":rsp.get("finish_reason"),"truncated":bool(rsp.get("truncated",False)),
                         "request_max_tokens":max_tokens,"request_temperature":temp,"request_timeout":timeout,
                         "response_chars":len(str(rsp.get("text","") or rsp.get("content","") or "")),
                         "controlled_suffix_chars":len(suffix),"final_system_chars":len(t.input.system_prompt or ""),
                         "final_system_sha256":hashlib.sha256((t.input.system_prompt or "").encode()).hexdigest(),"error":rec.error}
                    stream.write(json.dumps(row,ensure_ascii=False)+"\n");stream.flush();completed.add(key)
                    new_done+=1;durations.append(elapsed); total=done0+new_done; rem=max(0,planned-total); eta=(sum(durations)/len(durations))*rem
                    state="ERROR" if rec.error else "OK"
                    print(f"[{state}] {total}/{planned} {w.tag} {t.id} score={row['overall_score']:.4f} finish={row['finish_reason']} trunc={row['truncated']}")
                    print(f"[PROGRESS] {100*total/planned:.1f}% elapsed={_fmt(sum(durations))} eta={_fmt(eta)}")
    print(f"[DONE] output={out_root}")
    return out_root
