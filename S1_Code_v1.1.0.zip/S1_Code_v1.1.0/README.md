# S1 Code — MMGIS-Bench LASR v1.1.0

Revision code for the benchmark, controlled LASR prompt-policy variants, and the 11-setting weight-sensitivity runner.

## What is included

- `lasr/strategy.py` and `lasr/weights.py` — four LASR variants and the prespecified weight grid.
- `revision/lasr_runner.py` — four-condition ablation runner.
- `revision/weight_runner.py` — 11-setting weight-sensitivity runner.
- `benchmark/`, `models/`, `evaluation/`, `tasks/`, `configs/`, `scripts/` — benchmark and execution stack.
- `docs/revision_lasr_experiment.md` — experimental boundary and commands.

## Important implementation note

The released LASR code implements the scale partition as a **prompt-level policy**. `lasr/strategy.py` builds a treatment prompt that instructs the model to assess local, regional and global evidence and apply the fixed weights. The six compatibility terms in the manuscript are the intended semantic definition of those channels; they are not separately calibrated numeric predictors in this code. The paper must not claim that the prompt-policy run numerically instantiated the six terms.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q
python scripts/revision/run_lasr_ablation.py --config configs/revision/lasr_revision.yaml
python scripts/revision/run_lasr_weight_sensitivity.py --config configs/revision/lasr_revision.yaml
```

If a revision CLI path is absent, call `revision.lasr_runner.run_revision_experiment` directly; see `docs/revision_lasr_experiment.md`.

No API keys or `.env` files are included.
