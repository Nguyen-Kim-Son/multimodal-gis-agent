# MMGIS-Bench Revision 0.8.4 — experimental-control fix

This release tightens the LASR ablation after the 0.8.3 smoke run showed
treatment-dependent prompt length and very long completions.

## Controls introduced

1. **Identical final-answer contract.** Every condition must return exactly four
   concise sections: DATASETS, WORKFLOW, ASSUMPTIONS, VALIDATION.
2. **No chain-of-thought transcript.** The assigned policy is applied internally;
   the benchmark scores only the final workflow.
3. **Identical generation controls.** The revision config fixes `max_tokens=1200`,
   `temperature=0.0`, and `timeout=300` for every ablation condition, overriding
   task-level generation limits only inside this revision experiment.
4. **Compact treatment prompts.** The treatment-specific policy is concise. The
   evidence block and output contract are identical across conditions.
5. **Truncation audit.** OpenRouter `finish_reason` and a derived `truncated` flag
   are stored for every response.
6. **Prompt/output audit.** Each row records prompt/completion/total tokens,
   treatment/system character counts and hashes, response length, generation
   controls, latency and cost.
7. **Weight sensitivity inherits the same generation controls.**

The treatment prompts are intentionally not padded to identical token counts:
artificial padding could itself alter model behaviour. Instead, prompt-token
counts are recorded and must be reported/audited as a manipulation check.

## Required smoke run

```powershell
python scripts\revision\run_lasr_ablation.py `
  --config configs\revision\lasr_revision.yaml `
  --smoke-test
```

Then:

```powershell
python scripts\revision\audit_experimental_control.py `
  --run-dir outputs\revision\lasr_revision_v1_smoke
```

Do not launch the production run until the smoke audit confirms no truncation
and reasonably comparable response lengths across treatments.
