# Revision 0.8.3

This maintenance release adds observability and a safe smoke-run path for the
LASR revision experiment.

## Added

- Per-call `[RUN]` logging with condition, repeat, task ID, and task name.
- Per-call `[OK]` / `[ERROR]` logging.
- `[PROGRESS]` logging with completed calls, failure count, average wall time,
  elapsed time, and estimated remaining time (ETA).
- OpenRouter retry logging for HTTP 408/429/502/503/504 responses.
- Retry logging for transient `requests.RequestException` failures.
- `--smoke-test`, which:
  - keeps all four configured LASR variants,
  - uses one repeat,
  - selects a small deterministic spread of tasks,
  - writes to `<run_id>_smoke`, so production results are not contaminated.
- `--smoke-tasks N` to override the default smoke subset size.

## Recommended order

```powershell
python scripts\revision\preflight_revision.py
python -m pytest -q
python scripts\revision\run_lasr_ablation.py --config configs\revision\lasr_revision.yaml --smoke-test
python scripts\revision\run_lasr_ablation.py --config configs\revision\lasr_revision.yaml
```

The full experiment retains resume behavior. Stopping with Ctrl+C does not
delete completed JSONL rows.
