# LASR revision experiment

This revision package adds a controlled four-condition ablation without modifying the original 35-task ground truth or evaluator:

1. `full_lasr`: explicit local/regional/global scale partition with weights.
2. `single_scale`: local/neighbourhood reasoning only.
3. `pooled_context`: all evidence pooled without scale channels.
4. `retrieval_only`: semantic/basic metadata retrieval followed directly by workflow synthesis.

The task, declared datasets, model backend, temperature, evaluator and operation ontology are held fixed. The experiment therefore tests the contribution of the scale-partitioned reasoning policy to downstream workflow synthesis. It does **not**, by itself, establish physical correctness of the three LASR scale scores; that requires an additional layer-selection/compatibility validation dataset with explicit candidate-layer metadata and expert labels.

## Run

```powershell
python -m pytest -q
python scripts/revision/run_lasr_ablation.py --config configs/revision/lasr_revision.yaml
python scripts/revision/run_lasr_weight_sensitivity.py --config configs/revision/lasr_revision.yaml
python scripts/revision/build_lasr_revision_report.py --run-dir outputs/revision/lasr_revision_v1 --output reports/revision/lasr
```

## Outputs

- `lasr_ablation_raw.csv`
- `lasr_ablation_task_means.csv`
- `lasr_ablation_summary.csv`
- `lasr_ablation_paired_tests.csv`
- `lasr_weight_sensitivity_raw.csv`
- `lasr_weight_sensitivity_summary.csv`
- `table_lasr_ablation.csv`
- `figure_lasr_ablation.png`
- `figure_lasr_weight_sensitivity.png`

## Important inference boundary

The weight grid is predeclared. Do not choose a weight vector after inspecting test outcomes and then report it as confirmatory. Report sensitivity across the full grid. If the original 0.4/0.4/0.2 setting is not optimal, retain that fact transparently.
