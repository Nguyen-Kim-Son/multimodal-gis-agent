# Revision 0.8.5 — final experimental-control gate

Changes:
- identical bounded response contract across all four LASR conditions;
- 3–8 essential WORKFLOW operations, capped section/item lengths, target <=700 words;
- `max_tokens=1600` used only as a safety ceiling;
- automatic production gate checks exactly 8 smoke calls, identical two tasks
  across four conditions, one repeat, zero errors, zero truncation, identical
  generation controls, no length-limited finish reason, and no response using
  >=95% of the token ceiling;
- `--strict` makes a failed gate return exit status 2;
- `scripts/revision/smoke_lasr_8calls.ps1` runs exactly 8 calls then audits them.

A PASS is a technical manipulation/control check, not evidence that LASR is
superior. Scientific inference remains based on the full task-level experiment.
