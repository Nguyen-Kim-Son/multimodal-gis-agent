# Revision 0.8.6 — statistical-analysis fix

This release freezes the 0.8.5 experimental protocol and changes no prompts,
models, tasks, evaluator logic, or generation controls.

Statistical inference is performed at the level of the 35 unique tasks.
The three repeats are averaged within each task-condition before inference.

Primary analysis:
- task-level condition means with 10,000 nonparametric bootstrap resamples;
- paired Full-LASR-minus-comparator task differences;
- two-sided paired Wilcoxon signed-rank tests;
- rank-biserial paired effect sizes;
- Holm family-wise correction across the three prespecified Full LASR contrasts;
- wins/ties/losses over the 35 task-level paired differences.

The script also exports raw-response descriptives, component-level descriptive
summaries, publication CSV tables, 300-dpi figures, an integrity check, and a
manuscript-ready text summary. The 420 repeated responses are never treated as
420 independent inferential units.
