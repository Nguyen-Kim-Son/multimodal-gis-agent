# Revision 0.8.7 — prespecified LASR weight sensitivity

The primary 0.8.5/0.8.6 ablation is frozen. This is a separate robustness analysis, not hyperparameter selection.

Grid: 11 prespecified normalized L/R/G triplets, with 0.40/0.40/0.20 as the manuscript reference.
Smoke: exactly 11 weights x 2 fixed tasks x 1 repeat = 22 calls.
Production: exactly 11 weights x 35 tasks x 1 repeat = 385 calls.
The strict gate requires complete pairing, zero errors/truncation, identical generation controls, and token headroom.
