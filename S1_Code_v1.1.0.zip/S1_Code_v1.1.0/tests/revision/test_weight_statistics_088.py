import importlib.util
from pathlib import Path
import numpy as np
P=Path("scripts/revision/build_weight_sensitivity_report.py")
s=importlib.util.spec_from_file_location("wstat",P);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def test_holm_10():
 p=np.linspace(.01,.10,10);a=m.holm(p);assert len(a)==10 and np.all(a>=p) and np.all(a<=1)
def test_rb_direction():
 assert m.rb([1,2,3])==1 and m.rb([-1,-2,-3])==-1
