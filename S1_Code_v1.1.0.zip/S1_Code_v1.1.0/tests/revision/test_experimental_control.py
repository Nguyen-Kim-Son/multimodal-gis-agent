from lasr import LASRVariant, LASRWeights, build_reasoning_prompt
from lasr.strategy import COMMON_RESPONSE_CONTRACT, treatment_policy_text
from tasks import load_directory


def _task():
    return load_directory("tasks/contextgeo_unique35")[0]


def test_all_conditions_share_identical_output_contract():
    task = _task()
    for variant in LASRVariant:
        prompt = build_reasoning_prompt(task, variant)
        assert COMMON_RESPONSE_CONTRACT in prompt
        assert "Return only these four sections" in prompt
        assert "Do not reveal hidden chain-of-thought" in prompt


def test_policy_is_the_intended_treatment_difference():
    task = _task()
    prompts = {v: build_reasoning_prompt(task, v) for v in LASRVariant}
    assert len(set(prompts.values())) == 4
    assert "L=0.40" in prompts[LASRVariant.FULL]
    assert "Do not create regional/global channels" in prompts[LASRVariant.SINGLE]
    assert "one evidence pool" in prompts[LASRVariant.POOLED]
    assert "semantic relevance" in prompts[LASRVariant.RETRIEVAL_ONLY]


def test_treatment_prompts_are_compact():
    weights = LASRWeights()
    lengths = [len(treatment_policy_text(v, weights=weights).split()) for v in LASRVariant]
    assert max(lengths) < 70
    assert min(lengths) > 25
