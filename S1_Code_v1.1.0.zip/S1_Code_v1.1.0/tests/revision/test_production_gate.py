import importlib.util
from pathlib import Path

import pandas as pd

SCRIPT = Path("scripts/revision/audit_experimental_control.py")
spec = importlib.util.spec_from_file_location("audit_experimental_control", SCRIPT)
mod = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(mod)


def _good_df():
    rows = []
    for cond in ["full_lasr", "single_scale", "pooled_context", "retrieval_only"]:
        for task in ["A", "B"]:
            rows.append({
                "condition": cond, "task_id": task, "repeat": 1,
                "error": None, "truncated": False,
                "finish_reason": "stop", "completion_tokens": 800,
                "request_max_tokens": 1600, "request_temperature": 0.0,
                "request_timeout": 300,
            })
    return pd.DataFrame(rows)


def test_gate_passes_clean_eight_call_smoke():
    passed, reasons = mod.evaluate_gate(_good_df())
    assert passed
    assert reasons == []


def test_gate_fails_truncation():
    df = _good_df()
    df.loc[0, "truncated"] = True
    passed, reasons = mod.evaluate_gate(df)
    assert not passed
    assert any("truncation" in x for x in reasons)


def test_gate_fails_near_ceiling():
    df = _good_df()
    df.loc[0, "completion_tokens"] = 1530
    passed, reasons = mod.evaluate_gate(df)
    assert not passed
    assert any(">=95%" in x for x in reasons)
