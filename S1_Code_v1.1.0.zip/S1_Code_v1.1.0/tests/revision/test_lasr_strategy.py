from pathlib import Path
from lasr import LASRVariant, LASRWeights, build_reasoning_prompt, default_weight_grid
from tasks import load_directory


def test_weights_sum():
    w=LASRWeights(.4,.4,.2); assert abs(w.local+w.regional+w.global_-1)<1e-9


def test_grid_valid():
    assert len(default_weight_grid())>=10
    for w in default_weight_grid(): assert abs(w.local+w.regional+w.global_-1)<1e-8


def test_prompts_are_distinct():
    tasks=load_directory(Path('tasks/contextgeo_unique35'))
    task=tasks[0]
    texts={v.value:build_reasoning_prompt(task,v) for v in LASRVariant}
    assert len(set(texts.values()))==4
    assert 'POLICY: FULL LASR' in texts['full_lasr']
    assert 'POLICY: RETRIEVAL ONLY' in texts['retrieval_only']
