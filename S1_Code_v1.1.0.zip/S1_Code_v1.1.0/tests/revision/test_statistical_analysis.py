import importlib.util
from pathlib import Path
import numpy as np
import pandas as pd

P=Path("scripts/revision/build_lasr_statistical_report.py")
spec=importlib.util.spec_from_file_location("statrep",P)
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def test_holm_monotone_in_sorted_order():
    p=np.array([.01,.03,.2])
    a=m.holm_adjust(p)
    assert np.all(a>=p)
    assert np.all(a<=1)

def test_rank_biserial_direction():
    assert m.rank_biserial([1,2,3])==1.0
    assert m.rank_biserial([-1,-2,-3])==-1.0

def test_integrity_accepts_balanced_420():
    rows=[]
    for c in m.CONDITIONS:
        for t in range(35):
            for r in range(3):
                rows.append(dict(condition=c,task_id=f"T{t}",repeat=r,
                                 overall_score=.5,passed=True,truncated=False,error=None))
    assert m.integrity(pd.DataFrame(rows))==[]
