from revision.lasr_runner import _fmt_duration, _select_smoke_tasks


def test_fmt_duration():
    assert _fmt_duration(0) == "00:00"
    assert _fmt_duration(65) == "01:05"
    assert _fmt_duration(3661) == "01:01:01"


def test_smoke_selection_is_small_and_deterministic():
    tasks = list(range(10))
    a = _select_smoke_tasks(tasks, 2)
    b = _select_smoke_tasks(tasks, 2)
    assert a == b
    assert a == [0, 9]


def test_smoke_selection_clamps():
    tasks = list(range(3))
    assert _select_smoke_tasks(tasks, 99) == tasks
