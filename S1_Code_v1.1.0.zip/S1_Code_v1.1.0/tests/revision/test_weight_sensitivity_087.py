import importlib.util
from pathlib import Path
import pandas as pd
from revision.weight_runner import PRESPECIFIED_GRID
def test_prespecified_grid_is_11_and_normalized():
    assert len(PRESPECIFIED_GRID)==11
    assert PRESPECIFIED_GRID[0]==(0.4,0.4,0.2)
    assert all(abs(sum(w)-1)<1e-6 for w in PRESPECIFIED_GRID)
def test_smoke_design_is_exactly_22():
    assert len(PRESPECIFIED_GRID)*2*1==22
