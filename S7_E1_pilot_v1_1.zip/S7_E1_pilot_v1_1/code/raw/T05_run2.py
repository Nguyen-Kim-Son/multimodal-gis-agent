import ee, json
# AOI bounding box
aoi = ee.Geometry.Rectangle([105.75, 20.95, 105.85, 21.05], None, False)
# Load WorldCover 2021 Map band
img = ee.Image('ESA/WorldCover/v200/2021').select('Map')
# Boolean cropland mask where class = 40
cropland = img.eq(40)
# Reduce with mean to get area fraction
reduced = cropland.reduceRegion(ee.Reducer.mean(), geometry=aoi, scale=10, maxPixels=1e9, bestEffort=True)
val = None
if reduced and reduced.get('Map') is not None:
    val = float(reduced.get('Map').getInfo())
else:
    val = 0.0
print(json.dumps({"value": val, "unit": "fraction"}))
