import ee, json
img = ee.Image('ESA/WorldCover/v200/2021').select('Map')
mask = img.eq(40).rename('mask')
bbox = ee.Geometry.Rectangle([105.75, 20.95, 105.85, 21.05], 'EPSG:4326', False)
res = mask.reduceRegion(ee.Reducer.mean(), geometry=bbox, scale=10, maxPixels=1e9, bestEffort=True)
val = res.get('mask').getInfo()
if val is None:
    val = 0.0
print(json.dumps({"value": float(val), "unit": "fraction"}))
