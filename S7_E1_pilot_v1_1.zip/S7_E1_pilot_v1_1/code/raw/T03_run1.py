import ee, json
aoi = ee.Geometry.Rectangle([105.75, 20.95, 105.85, 21.05], proj='EPSG:4326', geodesic=False)
img = ee.Image('JRC/GHSL/P2023A/GHS_POP/2020').select('population_count')
res = img.reduceRegion(ee.Reducer.sum(), geometry=aoi, scale=100, maxPixels=1e9, bestEffort=True).getInfo()
val = None
if isinstance(res, dict):
    val = res.get('population_count')
    if val is None and len(res) > 0:
        val = list(res.values())[0]
if val is None:
    val_num = 0.0
else:
    val_num = float(val)
print(json.dumps({"value": val_num, "unit": "persons"}))
