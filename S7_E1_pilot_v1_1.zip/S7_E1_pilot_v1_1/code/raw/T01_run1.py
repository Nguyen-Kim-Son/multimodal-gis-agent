import ee, json

# AOI bounding box
aoi = ee.Geometry.Rectangle([105.75, 20.95, 105.85, 21.05], proj='EPSG:4326', geodesic=False)

# Filtered Sentinel-2 SR Harmonized collection for 2023 with cloud threshold
col = (ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
       .filterDate('2023-01-01', '2024-01-01')
       .filterBounds(aoi)
       .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)))

# Mask SCL classes 3,8,9,10,11
def mask_scl(img):
    scl = img.select('SCL')
    mask = scl.neq(3).And(scl.neq(8)).And(scl.neq(9)).And(scl.neq(10)).And(scl.neq(11))
    return img.updateMask(mask)

col_masked = col.map(mask_scl)

# Median composite and clip to AOI
median = col_masked.median().clip(aoi)

# Compute NDVI (B8 - B4) / (B8 + B4)
nd = median.normalizedDifference(['B8', 'B4']).rename('nd')

# Reduce region: mean NDVI over AOI at 10 m
reduced = nd.reduceRegion(
    reducer=ee.Reducer.mean(),
    geometry=aoi,
    scale=10,
    maxPixels=1e9,
    bestEffort=True
)

value = reduced.get('nd').getInfo()

print(json.dumps({'value': value, 'unit': 'NDVI'}))
