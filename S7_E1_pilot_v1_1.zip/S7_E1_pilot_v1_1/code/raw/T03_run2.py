import ee, json
# AOI bbox [minx, miny, maxx, maxy] in EPSG:4326
aoi = ee.Geometry.Rectangle([105.75, 20.95, 105.85, 21.05], proj='EPSG:4326', geodesic=False)
img = ee.Image('JRC/GHSL/P2023A/GHS_POP/2020').select('population_count')
sum_val = img.reduceRegion(reducer=ee.Reducer.sum(), geometry=aoi, scale=100, maxPixels=1e9, bestEffort=True).get('population_count').getInfo()
if sum_val is None:
    sum_val = 0
print(json.dumps({'value': sum_val, 'unit': 'persons'}))
