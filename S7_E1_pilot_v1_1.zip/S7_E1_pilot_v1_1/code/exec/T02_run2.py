import ee, os
ee.Initialize(project=os.environ['EE_PROJECT'])
import ee
import json

# Elevation and slope
elev = ee.Image('USGS/SRTMGL1_003')
slope = ee.Terrain.slope(elev)

# AOI bounding box
aoi = ee.Geometry.Rectangle([105.75, 20.95, 105.85, 21.05], 'EPSG:4326', False)

# Reduce to mean slope
stats = slope.reduceRegion(
    reducer=ee.Reducer.mean(),
    geometry=aoi,
    scale=30,
    maxPixels=int(1e9),
    bestEffort=True
)

mean_slope = stats.get('slope').getInfo()
print(json.dumps({'value': mean_slope, 'unit': 'degrees'}))
