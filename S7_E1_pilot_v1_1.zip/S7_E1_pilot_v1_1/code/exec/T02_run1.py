import ee, os
ee.Initialize(project=os.environ['EE_PROJECT'])
import ee, json

# AOI bounding box [minLon, minLat, maxLon, maxLat]
aoi = ee.Geometry.Rectangle([105.75, 20.95, 105.85, 21.05])

elev = ee.Image('USGS/SRTMGL1_003')
slope = ee.Terrain.slope(elev)

result = slope.reduceRegion(
    reducer=ee.Reducer.mean(),
    geometry=aoi,
    scale=30,
    maxPixels=1e9,
    bestEffort=True
)

mean_slope = result.get('slope').getInfo()
print(json.dumps({'value': float(mean_slope), 'unit': 'degrees'}))
