import ee, os
ee.Initialize(project=os.environ['EE_PROJECT'])
import ee, json

# AOI bounding box
aoi = ee.Geometry.Rectangle([105.75, 20.95, 105.85, 21.05], None, False)

# Load occurrence band and create area image for pixels with occurrence > 50%
occ = ee.Image('JRC/GSW1_4/GlobalSurfaceWater').select('occurrence')
area_km2_img = occ.gt(50).multiply(ee.Image.pixelArea()).divide(1e6).rename('area_km2')

# Reduce to sum area within AOI
reduced = area_km2_img.reduceRegion(
    reducer=ee.Reducer.sum(),
    geometry=aoi,
    scale=30,
    maxPixels=1e9,
    bestEffort=True
)

# Get the value client-side
value = reduced.get('area_km2').getInfo()
if value is None:
    value = 0.0

print(json.dumps({"value": float(value), "unit": "km2"}))
