import ee, os
ee.Initialize(project=os.environ['EE_PROJECT'])
import ee, json

# AOI bounding box
aoi = ee.Geometry.Rectangle([105.75, 20.95, 105.85, 21.05], None, False)

# Sentinel-2 SR Harmonized collection for 2023 with cloud filter
col = (
    ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
    .filterDate('2023-01-01', '2024-01-01')
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
)

# Mask SCL classes 3,8,9,10,11 on each image
def mask_bad_scl(img):
    scl = img.select('SCL')
    mask = scl.neq(3).And(scl.neq(8)).And(scl.neq(9)).And(scl.neq(10)).And(scl.neq(11))
    return img.updateMask(mask)

masked_col = col.map(mask_bad_scl)

# Median composite and clip to AOI
median_img = masked_col.median().clip(aoi)

# Compute NDVI and reduceRegion mean
ndvi = median_img.normalizedDifference(['B8', 'B4']).rename('NDVI')
mean_dict = ndvi.reduceRegion(
    reducer=ee.Reducer.mean(),
    geometry=aoi,
    scale=10,
    maxPixels=1e9,
    bestEffort=True
)

mean_value = mean_dict.get('NDVI').getInfo()

print(json.dumps({"value": mean_value, "unit": "NDVI"}))
