import ee, os
ee.Initialize(project=os.environ['EE_PROJECT'])
import ee, json

# Image and AOI
occurrence = ee.Image('JRC/GSW1_4/GlobalSurfaceWater').select('occurrence')
aoi = ee.Geometry.Rectangle([105.75, 20.95, 105.85, 21.05], 'EPSG:4326')

# Mask occurrence > 50%, multiply by pixel area, convert m^2 to km^2
area_img = occurrence.gt(50).multiply(ee.Image.pixelArea()).divide(1e6).rename('area_km2')

# Reduce
result_dict = area_img.reduceRegion(
    reducer=ee.Reducer.sum(),
    geometry=aoi,
    scale=30,
    maxPixels=1e9,
    bestEffort=True
).getInfo()

value = float(result_dict.get('area_km2') or 0.0)

print(json.dumps({"value": value, "unit": "km2"}))
