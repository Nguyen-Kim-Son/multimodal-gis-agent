# S7 — E1 execution-level equivalence pilot

- Model: openai/gpt-5-mini
- Tasks: 5; runs: 2 per task; records: 10; passed: 10
- Run window: 2026-10-25T17:28:49Z to 2026-10-25T17:31:16Z
- Tolerances: absolute 0.01 (NDVI, cropland fraction); relative 2% (slope, population, water)
- All ten `candidate_code_sha256` values match the raw files after newline normalization; the uploaded files use CRLF, while the runner hashed LF text.
- `pilot_id` inside each record reads `..._v1` because the field was hard-coded in the runner; `output_manifest.json` records the protocol as `..._v1_1`.
- The earlier 6/10 debug run is excluded: it contained a wrong GHSL band name and a wrong WorldCover asset type, both task-definition errors.
- `output_manifest.json` retains the hashes written at run time. `S7_MANIFEST.json` re-hashes every file in this folder.
