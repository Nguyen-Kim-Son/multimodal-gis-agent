#!/usr/bin/env python3
"""Reference implementations for the five E1 tasks. Prints one JSON object."""
import argparse
import json
import os
import sys

import ee


def aoi():
    return ee.Geometry.Rectangle([105.75, 20.95, 105.85, 21.05], proj="EPSG:4326", geodesic=False)


def t01():
    geom = aoi()
    col = (
        ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
        .filterDate("2023-01-01", "2024-01-01")
        .filterBounds(geom)
        .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", 20))
    )
    img = col.median().clip(geom)
    scl = img.select("SCL")
    mask = (
        scl.neq(3).And(scl.neq(8)).And(scl.neq(9)).And(scl.neq(10)).And(scl.neq(11))
    )
    ndvi = img.normalizedDifference(["B8", "B4"]).rename("NDVI").updateMask(mask)
    val = ndvi.reduceRegion(
        reducer=ee.Reducer.mean(), geometry=geom, scale=10,
        maxPixels=int(1e9), bestEffort=True,
    ).get("NDVI")
    return float(ee.Number(val).getInfo()), "NDVI"


def t02():
    geom = aoi()
    slope = ee.Terrain.slope(ee.Image("USGS/SRTMGL1_003")).rename("slope")
    val = slope.reduceRegion(
        reducer=ee.Reducer.mean(), geometry=geom, scale=30,
        maxPixels=int(1e9), bestEffort=True,
    ).get("slope")
    return float(ee.Number(val).getInfo()), "degrees"


def t03():
    geom = aoi()
    pop = ee.Image("JRC/GHSL/P2023A/GHS_POP/2020").select("population_count").rename("population")
    val = pop.reduceRegion(
        reducer=ee.Reducer.sum(), geometry=geom, scale=100,
        maxPixels=int(1e9), bestEffort=True,
    ).get("population")
    return float(ee.Number(val).getInfo()), "persons"


def t04():
    geom = aoi()
    water = (
        ee.Image("JRC/GSW1_4/GlobalSurfaceWater")
        .select("occurrence")
        .gt(50)
        .multiply(ee.Image.pixelArea())
        .divide(1e6)
        .rename("area_km2")
    )
    val = water.reduceRegion(
        reducer=ee.Reducer.sum(), geometry=geom, scale=30,
        maxPixels=int(1e9), bestEffort=True,
    ).get("area_km2")
    return float(ee.Number(val).getInfo()), "km2"


def t05():
    geom = aoi()
    wc = ee.Image("ESA/WorldCover/v200/2021").select("Map")
    crop = wc.eq(40)
    val = crop.reduceRegion(
        reducer=ee.Reducer.mean(), geometry=geom, scale=10,
        maxPixels=int(1e9), bestEffort=True,
    ).get("Map")
    return float(ee.Number(val).getInfo()), "fraction"


TASKS = {"T01": t01, "T02": t02, "T03": t03, "T04": t04, "T05": t05}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("task", choices=sorted(TASKS))
    ap.add_argument("--project", default=os.environ.get("EE_PROJECT"))
    args = ap.parse_args()
    if not args.project:
        raise SystemExit("Set EE_PROJECT or pass --project")
    ee.Initialize(project=args.project)
    value, unit = TASKS[args.task]()
    print(json.dumps({"task_id": args.task, "value": value, "unit": unit}, allow_nan=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(json.dumps({"error": f"{type(exc).__name__}: {exc}"}))
        sys.exit(1)
