# S2 Data — LASR ablation v1.1.0

140 task-condition rows = 35 tasks × 4 conditions; three repeats per task-condition were averaged before inference. Includes task-level means, the publication table, and three primary paired contrasts.

Full LASR 0.568; single-scale 0.559; pooled-context 0.596; retrieval-only 0.558. No primary contrast survived Holm correction (all adjusted p = 1.000). The 0.568 reference is a three-repeat cohort and is not the same estimate as the 0.547 one-run reference in S3.
