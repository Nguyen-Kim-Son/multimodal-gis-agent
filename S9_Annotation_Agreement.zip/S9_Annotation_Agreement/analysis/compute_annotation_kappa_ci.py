#!/usr/bin/env python3
"""Cohen's kappa, Jaccard, set-F1 and task-bootstrap confidence intervals.

Inputs are two CSV files with a task id column and an operation-list column.
Operation lists may be JSON arrays or delimited by ';', '|' or ','.
The bootstrap resamples tasks, not operation pairs.
"""
import argparse
import csv
import hashlib
import json
import math
import random
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path

ID_COLS = ("task_id", "id", "task")
OP_COLS = ("required_operations", "operations", "operation_set", "ops")


def utc_now():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def normalise_op(text):
    text = text.strip().lower()
    text = re.sub(r"[\s\-]+", "_", text)
    return re.sub(r"[^a-z0-9_.]", "", text)


def parse_ops(value):
    if value is None:
        return set()
    value = str(value).strip()
    if not value or value.lower() in ("nan", "none", "null", "[]"):
        return set()
    if value.startswith("["):
        try:
            data = json.loads(value)
            return {normalise_op(str(x)) for x in data if str(x).strip()}
        except json.JSONDecodeError:
            pass
    parts = re.split(r"[;|,]", value)
    return {normalise_op(x) for x in parts if x.strip()}


def read_labels(path):
    with open(path, newline="", encoding="utf-8-sig") as fh:
        rows = list(csv.DictReader(fh))
    if not rows:
        raise SystemExit(f"empty CSV: {path}")
    cols = {c.lower(): c for c in rows[0].keys()}
    id_col = next((cols[c] for c in ID_COLS if c in cols), None)
    op_col = next((cols[c] for c in OP_COLS if c in cols), None)
    if not id_col or not op_col:
        raise SystemExit(f"{path}: need a task id column and an operation-list column; found {list(rows[0])}")
    out = {}
    for row in rows:
        tid = str(row[id_col]).strip()
        if tid:
            out[tid] = parse_ops(row[op_col])
    return out


def kappa_from_pairs(pairs):
    n = len(pairs)
    if n == 0:
        return float("nan")
    agree = sum(1 for a, b in pairs if a == b)
    po = agree / n
    pa = sum(a for a, _ in pairs) / n
    pb = sum(b for _, b in pairs) / n
    pe = pa * pb + (1 - pa) * (1 - pb)
    if pe >= 1:
        return float("nan")
    return (po - pe) / (1 - pe)


def task_pairs(a, b, vocab=None):
    shared = sorted(set(a) & set(b))
    union = sorted(set(vocab)) if vocab else sorted(set(a) | set(b))
    observed = sorted(set(a) | set(b))
    return [(1 if op in a else 0, 1 if op in b else 0) for op in union], shared, observed


def metrics(tasks, vocab=None):
    pairs = []
    jac, f1, agree_pairs = [], [], []
    for a, b in tasks:
        tp, shared, union = task_pairs(a, b, vocab)
        pairs.extend(tp)
        if union:
            jac.append(len(shared) / len(union))
            f1.append(2 * len(shared) / (len(a) + len(b)) if (len(a) + len(b)) else 1.0)
        agree_pairs.extend(1 if x == y else 0 for x, y in tp)
    return {
        "kappa": kappa_from_pairs(pairs),
        "percent_agreement": (sum(agree_pairs) / len(agree_pairs)) if agree_pairs else float("nan"),
        "mean_jaccard": (sum(jac) / len(jac)) if jac else float("nan"),
        "mean_set_f1": (sum(f1) / len(f1)) if f1 else float("nan"),
        "n_pairs": len(pairs),
        "n_tasks_with_operations": len(jac),
    }


def quantile(values, q):
    values = sorted(v for v in values if not math.isnan(v))
    if not values:
        return float("nan")
    k = (len(values) - 1) * q
    lo, hi = math.floor(k), math.ceil(k)
    if lo == hi:
        return values[lo]
    return values[lo] + (values[hi] - values[lo]) * (k - lo)


def bootstrap(tasks, n_boot, seed, vocab=None):
    rng = random.Random(seed)
    draws = {"kappa": [], "percent_agreement": [], "mean_jaccard": [], "mean_set_f1": []}
    for _ in range(n_boot):
        sample = [tasks[rng.randrange(len(tasks))] for _ in range(len(tasks))]
        m = metrics(sample, vocab)
        for key in draws:
            draws[key].append(m[key])
    return {key: [quantile(vals, 0.025), quantile(vals, 0.975)] for key, vals in draws.items()}


def self_test():
    tmp = Path(tempfile.mkdtemp())
    a = tmp / "annotator_A.csv"; b = tmp / "annotator_B.csv"
    rows = [
        ("T1", ["ndvi", "cloud_mask", "reduce_mean"]),
        ("T2", ["slope", "reduce_mean"]),
        ("T3", ["population", "zonal_sum"]),
        ("T4", ["water", "threshold", "area"]),
        ("T5", ["landcover", "class_40", "area_fraction"]),
        ("T6", ["rainfall", "anomaly", "mean"]),
        ("T7", ["forest", "loss", "area"]),
        ("T8", ["elevation", "slope", "mean"]),
    ]
    with open(a, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(["task_id", "required_operations"])
        for t, ops in rows: w.writerow([t, ";".join(ops)])
    with open(b, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(["task_id", "required_operations"])
        for t, ops in rows:
            if t == "T5": w.writerow([t, ";".join(ops[:-1] + ["area"])])
            elif t == "T7": w.writerow([t, ";".join(ops[:-1] + ["area"])])
            else: w.writerow([t, ";".join(ops)])
    out = run(a, b, 2000, 7)
    print(json.dumps({"self_test": True, "kappa": out["kappa"], "ci": out["kappa_ci"], "n_tasks": out["n_tasks"]}, indent=2))


def run(a_path, b_path, n_boot, seed, vocab=None):
    A = read_labels(a_path); B = read_labels(b_path)
    shared = sorted(set(A) & set(B))
    if not shared:
        raise SystemExit("no shared task ids between the two files")
    tasks = [(A[t], B[t]) for t in shared]
    point = metrics(tasks, vocab)
    ci = bootstrap(tasks, n_boot, seed, vocab)
    per_task = []
    for t, (a, b) in zip(shared, tasks):
        tp, sh, un = task_pairs(a, b, vocab)
        per_task.append({
            "task_id": t, "n_union": len(un), "n_shared": len(sh),
            "jaccard": (len(sh) / len(un)) if un else None,
            "set_f1": (2 * len(sh) / (len(a) + len(b))) if (len(a) + len(b)) else None,
        })
    return {
        "record_type": "ANNOTATION_AGREEMENT_V1",
        "generated_utc": utc_now(),
        "inputs": {
            "a": {"path": str(Path(a_path).resolve()), "sha256": sha256_file(a_path)},
            "b": {"path": str(Path(b_path).resolve()), "sha256": sha256_file(b_path)},
        },
        "n_tasks": len(shared),
        "missing_in_a": sorted(set(B) - set(A)),
        "missing_in_b": sorted(set(A) - set(B)),
        "n_operation_pairs": point["n_pairs"],
        "kappa": point["kappa"],
        "kappa_ci": ci["kappa"],
        "percent_agreement": point["percent_agreement"],
        "percent_agreement_ci": ci["percent_agreement"],
        "mean_jaccard": point["mean_jaccard"],
        "mean_jaccard_ci": ci["mean_jaccard"],
        "mean_set_f1": point["mean_set_f1"],
        "mean_set_f1_ci": ci["mean_set_f1"],
        "per_task": per_task,
        "method": "Unweighted Cohen's kappa over the union of operations per task; 95% percentile intervals from task-level bootstrap; Jaccard and set-F1 averaged over tasks with a non-empty union.",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", required=False)
    ap.add_argument("--b", required=False)
    ap.add_argument("--boot", type=int, default=10000)
    ap.add_argument("--vocab", default=None, help="JSON with an operations list; fixes the kappa universe.")
    ap.add_argument("--seed", type=int, default=20261026)
    ap.add_argument("--out", default=str(Path(__file__).resolve().parents[1] / "outputs" / "annotation_agreement.json"))
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        self_test()
        return
    if not args.a or not args.b:
        raise SystemExit("--a and --b are required")
    vocab = None
    if args.vocab:
        vd = json.load(open(args.vocab, encoding="utf-8"))
        vocab = vd.get("operations") or vd
        if not isinstance(vocab, list):
            raise SystemExit("vocab JSON must contain an operations list")
    out = run(args.a, args.b, args.boot, args.seed, vocab)
    out["vocab"] = {"path": str(Path(args.vocab).resolve()), "sha256": sha256_file(args.vocab), "n_operations": len(vocab)} if args.vocab else None
    p = Path(args.out); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps({k: out[k] for k in ("n_tasks", "n_operation_pairs", "kappa", "kappa_ci", "percent_agreement", "mean_jaccard", "mean_set_f1")}, indent=2))
    print(f"wrote {p}")


if __name__ == "__main__":
    main()
