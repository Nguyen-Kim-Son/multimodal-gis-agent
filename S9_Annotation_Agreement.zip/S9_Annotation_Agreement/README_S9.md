# S9 — Operation annotation and agreement (35-task benchmark)

## Contents

- `annotations/ANNOTATOR_A_35.csv`, `ANNOTATOR_B_35.csv` — per-task required operations for the 35 benchmark tasks.
- `annotations/vocabulary_22.json` — fixed 22-operation vocabulary used as the kappa universe.
- `adjudication/ground_truth_agreement.json` — pre-adjudication summary.
- `adjudication/adjudicated_ground_truth.json` — adjudicated reference decisions.
- `adjudication/ground_truth_adjudication_decisions.json` — coordinator decisions.
- `tasks/tasks_35.json` — task definitions and prompts.
- `analysis/annotation_agreement_35.json` — regenerated agreement statistics.
- `analysis/compute_annotation_kappa_ci.py` — reproducible script.

## Result

- 35 tasks x 22 operations = **770 binary pairs**.
- Cohen's kappa = **0.6911** (95% CI **0.6271--0.7478**, 10,000 task-bootstrap resamples).
- Percent agreement = **89.48%**.
- Mean task Jaccard = **0.6062**.
- Mean set-F1 = **0.7281**.
- Out-of-vocabulary terms: `calculate_lst`, `zonal_statistics`.

## Reproduction

```bash
python analysis/compute_annotation_kappa_ci.py \
  --a annotations/ANNOTATOR_A_35.csv \
  --b annotations/ANNOTATOR_B_35.csv \
  --vocab annotations/vocabulary_22.json --boot 10000
```

Kappa is computed over the fixed 22-operation vocabulary for each task, not over the per-task union; Jaccard and set-F1 use the observed per-task union.

## Provenance and limits

- Both annotation records report `independent_work_attested: true` and `prior_exposure: null`; blinding is attested but **not independently audited**.
- The blank templates at `data/v1/annotations/` (65 prospective rows, no operations) are **not** the source of this analysis and must not be submitted as labels.
- Agreement describes the submitted labels; out-of-vocabulary disagreements require review rather than silent exclusion.
